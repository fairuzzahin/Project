<?php 
	#session_start();
	if(!isset($_COOKIE['status'])){ 
		header('location: ../views/login.php');
	}
?>