<?php 
    require('../views/header.php');
	session_start();
	$myId=$_SESSION['id'];

	$file = fopen('../models/user.txt', 'r');

	while (!feof($file)) {
		$user = fgets($file);
		$userArray = explode("|", $user);
        if(isset($userArray[4])){
		if(trim($userArray[4]) == $myId){
			$editUser = $userArray;
			break;
		}}
	}
 
		//$id= $_GET['id'];
		$strings = file_get_contents('../models/user.txt'); 
$updateString=$editUser[0]."|".$editUser[1]."|".$editUser[2]."|"."2"."|".$editUser[4]."|".$editUser[5];
 $oldString=$editUser[0]."|".$editUser[1]."|".$editUser[2]."|".$editUser[3]."|".$editUser[4]."|".$editUser[5];

		$newStrings=str_replace($oldString, $updateString, $strings);
		$file = fopen('../models/user.txt', 'w');
		fwrite($file, $newStrings);
		$newStrings="";

		//header('location: ../views/edit.php?');


?>

<html>
<head>
	<title>Edit User</title>
</head>
<body>

	<form method="POST" action="">
		<table>
			<tr><td align="center"> <h3>Thank You<b></h3>
		<a href="../views/homePage.php"><img src="../models/logos/CrowdContent-logos.jpeg" alt="image" style="width:600px;height:600px"></a></td>
		</td>
	</tr>
		</table>
	</form>
</body>
</html>

