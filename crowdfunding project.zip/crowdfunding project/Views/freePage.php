<?php
// Start the session
require('../views/header.php');
require('../models/userModel.php');
session_start();
$name=$_SESSION['name'];
$myId=$_SESSION['id'];

?>
<!DOCTYPE html>
<html>
<head>
<title></title>
	<style type="text/css">
		.header {
			background-color:lightyellow;
		}
		.side {
			background-color:linen;
		}
		.Caption {
			font-size: 15px;

		}
	</style>
</head>
<body>
	<table  width="100%" >
		<tr class="header"> <! The Header Contain Logo , Navigations etc>

			<td colspan="2" ><a href="../views/homePage.php"><img src="../models/logos/CrowdContent-logos.jpeg" alt="image" style="width:60px;height:60px"></a></td>
			<td align="right">
				<a href="../views/member.php">Upgrade</a>
				<a href="../controllers/logout.php">Logout</a></td>
		</tr>

		<tr > 
			<td width="30%" valign="top" class="side">
			<h3> <?=$name?><a href="../views/freeUser.php">- View Profile</a></h3></td>


			<td width="40%">
				<style>
	          		body {
			        margin-bottom: 200%;
			        }

			        /* Box styles */
			        .myBox {
			        	background-color: lightyellow;
				        border: none;
				        padding: 5px;
				        font: 24px/36px sans-serif;
				        width: 620px;
				        height: 700px;
				        overflow: scroll;
			        } 

			    </style>
		        <div class="myBox">
		        	<?php
						$con=getConnection();
						$sql="select * FROM content ";
						$data=mysqli_query($con,$sql);
						while($row=mysqli_fetch_assoc($data)){ ?>
					
					<?php  $content=$row['content'];
					    $cid=$row['Id'];
					    $ctype=$row['type'];
					    $caption=$row['caption'];
					    $contentCreator=getUserByID($cid);
					    $cName=$contentCreator['1'];
					    $cPicture=$contentCreator['5'];
					    ?>
                        <a href="../views/profile.php?id=<?=$cid?>"><img src="<?=$cPicture?>" alt='image' style="width:60px; /*profile picture*/
                        height:60px; border-radius:30px;"><?=$cName?></a></br>
                        <?php 
                        if($ctype==1){ ?>
                        <a href="../views/member.php"><img src="../assets/logos/01unlockPost.png" alt='image' style="width:600px;border-radius: 15px 15px;"></a></br> 
                                                <h3>     </h3> 
                        <?php }
                        else{ ?>

                        <h3 class="Caption"><?=$caption?></h3>
					    <img src="<?=$content?>" alt='image' style="width:600px;border-radius: 15px 15px;"></br>  
					    <h3>     </h3>
					
                        <?php
                        } 
					    } ?>
					?>
				</div>


			</td>
			<td width="30%" valign="top" class="side">
				<h3>People you are following </h3><br>
				<?php
		        $file = fopen('../models/follow.txt', 'r');

		              while (!feof($file)) {
		              $profile = fgets($file);
		              $profileInfo = explode("|", $profile);
		              if(isset($profileInfo[0])&&isset($profileInfo[1])){
		              ?>
                    
		            <a href="../views/profile.php?id=<?=$profileInfo[0]?>">🔴<?=$profileInfo[1]?></a><br>
	


		        <?php } } ?>
			</td>
		</tr>
	</table>
</body>
</html>