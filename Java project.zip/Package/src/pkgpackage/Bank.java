

package pkgpackage;



public interface Bank {
    public void addAccount();
}
