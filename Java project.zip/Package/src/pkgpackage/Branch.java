

package pkgpackage;



public interface Branch {
    public void addBranch();
    
}
