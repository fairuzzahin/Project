

public class Start {

            	public static void main(String args[]){
Account a1=new Account("Sabbir","1188",7000.0);
 SavingsAccount s1=new  SavingsAccount("Karim","1120",1000.0,5.0);
SavingsAccount s2=new  SavingsAccount("Sakhib","1134",3000.0,5.5);
SavingsAccount s3=new  SavingsAccount("Musfiq',"1190",3000.0,6.0);
FixedAccount f3=new FixedAccount("Rahman","fa111",1500.0,4);		
FixedAccount f4=new FixedAccount("Sharif","1146",30000.0,2);	
FixedAccount f5=new FixedAccount("RAfiq","6954",4000.0,4);
Customer c1=new Customer (1,"Sakib");
Customer c2=new Customer (2,"Fahim");
Customer c3=new Customer (3,"Farhat");
Loan k1=new Loan('2140",2000.0,"private");
s1.deposit(1000.0);
s1.withdraw(500.0);
s1.displayinfo();
s2.displayinfo();
a1.displayinfo();
a1.deposit(2000.0);
a1.withdraw(500.0);
f1.displayinfo();
k1.display();
c1.addSavingsAccount(s1);
c1.addSavingsAccount(s2);
c1.addSavingsAccount(s3);
c1.addFixedAccount(f3);
c1.addFixedAccount(f4);
c1.addFixedAccount(f5);
k1.addcustomer(c1);
k1.addcustomer(c2);
k1.addcustomer(c3);

		System.out.println("Customer's Name is : "+c1.getName());
		System.out.println("Customer's Nid is : "+c1. getNid());
		c1. showAllSavingsAccounts();
		c1. removeAllSavingsAccounts(s3)
		 c1.showAllSavingsAccounts()
		 c1.showAllFixedAccounts();
		 c1.removeAllFixedAccounts(f4);
		  c1.showAllFixedAccounts();
		
		
	}
}
	

        
		
