

package Association;


public class Loan {
   
	private String loanno;
	private double amount;
	private String type;
	Customer customers[] =new Customer[5];
	public Loan(){
            System.out.println("Nothing is printed");
        }
public Loan(String loanno,double amount, String type){
this.loanno=loanno;

this.amount=amount;
this.type=type;

}

	public void setLoanno(String loanno)
	{
		this.loanno=loanno;
	}
	public void setAmount(double amount)
	{
		this.amount=amount;
	}
	public void setType(String type)
	{
		this.type=type;
	}
	public String  getLoanno()
	{
		return loanno;
	}
	public double getAmount()
	{
		return amount;
	}
	public String getType()
	{
		return type;
	}
	public void addCustomer(Customer customer)
	{
		int flag=0;
		for(int i=0;i<customers.length;i++)	
		{
			if(customers[i]== null)
			{
			customers[i]=customer;
			flag=1;
			break;
			}
			
		}
		if(flag==1)
		{
			System.out.println("Customer inserted.");
		}
		else
		{
			System.out.println("Customer can not be inserted.");
		}	
	}
        public void display(){
        System.out.println("Loan no:"+loanno);
        System.out.println("Amount:"+amount);
         System.out.println("Type:"+type);
        }
        
        
                
}


    

