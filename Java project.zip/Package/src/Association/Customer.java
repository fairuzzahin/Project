

package Association;

import pkgpackage.Class.*;
public class Customer {
  
	
    
    
    
    
    FixedAccount inserted ");
		}
		else
		{
			System.out.println("FixedAccount can not be inserted.");
		}	
	}
	public void removeFixedAccount(FixedAccount fixedAccount){
		int flag=0;
		for(int i=0; i<fixedAccount.length;i++){
			
		
			if(fixedAccounts[i]==fixedAccount)
			{
			fixedAccounts[i]=null;	
		
		flag=1;
			break;
			}
			
		}
		if(flag==1)
		{
			System.out.println("FixedAccount is removed	 ");
		}
		else
		{
			System.out.println("FixedAccount can not be removed");
		}	
	}
	public void showAllFixedAccounts(){
		for(int i=0; i<fixedAccount.length;i++){
			System.out.println("Tenureyear:"+FixedAccounts[i].getTenureyear());
		}
	}
}




    
}
