

package Class;


import pkgpackage.*;
public class FixedAccount extends Account {
	private int tenureYear;
	public FixedAccount(){
		System.out.println("Non-parameterized constructor called");
	}
	public FixedAccount(String accountholdername, String accountNo, double balance,int tenureYear){
		super(accountholdername, accountNo, balance);
		this.tenureYear=tenureYear;
	}
	public void setTenureyear(int tenureYear){
		this.tenureYear=tenureYear;
	}
	public int getTenureyear(){
		return  tenureYear;
	}
public void displayInfo(){
System.out.println("Tenureyear:"+tenureYear);
}

    
}
