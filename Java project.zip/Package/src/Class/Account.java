



public class Account implements Bank,Branch{
    
    private String accountholdername;
	private String accountNo;
	private double balance;
	public Account(){
		System.out.println("Non-parameterized constructor called");
	}
	public Account(String accountholdername ,String accountNo,double balance){
        this. accountholdername= accountholdername;
		this.accountNo=accountNo;
		this. balance= balance;
	}  
	public boolean deposit(double amount){
        if(amount > 0 ){
            this.balance += amount;
            return true;
        }
        return false;
    }
	public abstract boolean withdraw(double amount);
	public boolean transferAmount(Account account, double amount){
        if(account.balance - amount >=0){
            this.balance += amount;
            account.balance = account.balance - amount;
            return true;
        }
        return false;
    }
        public void addAccount(){
            System.out.println("Account is added");
        }
        public void addBranch(){
            System.out.println("Branch is added");
        }

    public void setAccountholdername(String accountholdername){
        this.accountholdername= accountholdername;
    }
	public void setAccountNo(String accountNo){
		this.accountNo= accountNo;
	}
	public void setBalance(double balance){
	    this.balance= balance;
	}
    public  String getAccountholdername(){
        return   accountholdername;
    }
	public String getAccountNo(){
	    return accountNo;
	}
	public double getBalance(){
		return balance;
	}
public void displayInfo(){
System.out.println("Accountholdername:"+ accountholdername);
System.out.println("AccountNo:"+ accountNo);
System.out.println("Balance:"+balance);
}
}
    
			
    
    
