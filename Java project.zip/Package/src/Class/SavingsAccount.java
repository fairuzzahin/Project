

package Class;

import pkgpackage.*;
public class SavingsAccount extends Account {
    private double interestRate;
	public  SavingsAccount(){
		System.out.println("Non-parameterized constructor called");
	}
	public  SavingsAccount(String accountholdername ,String accountNo,double balance, double interestRate){
		super(accountholdername,accountNo,balance);
		this.interestRate=interestRate;
	}
	public void setInterestRate(double interestRate){
this.interestRate=interestRate;
	}
	public double getInterestRate(){
	return interestRate;}
public void deposit(float amount)
    {
        if (amount>0.0)
            balance = balance + amount;
    }
    public void withdraw(float amount)
    {
        if ((amount>0.0)&&(balance>amount))
            balance = balance - amount;
    }

    public void displayinfo()
    {
        System.out.println("InterestRate :"+ interestRate);
    }


    
}
