

package Filereadwrite;
import java.lang.*;
import java.util.*;



public class NewClass {


	public static void main(String args[])
	{
		FileReadWriteDemo frwd = new FileReadWriteDemo();
	
		System.out.println("----------------------");
		frwd.writeInFile("Hello World");
		frwd.readFromFile();
		System.out.println("----------------------");
		frwd.writeInFile("Hello Java");
		frwd.readFromFile();
		
    
}
        
    }
