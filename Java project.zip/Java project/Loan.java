public class Loan implements Policy{
	public void loanPolicy(){
		System.out.println("This Bank Does Not Give Loan");
	}
}