public class Withdraw implements InterfaceWithdraw{
	public boolean withdraw(double amount) {
        if(getBalance()-amount >= 100){
            setBalance(getBalance()-amount);
            return true;
        }
        return false;
    }
}	