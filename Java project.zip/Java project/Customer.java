import java.util.ArrayList;
import java.util.Scanner;

public class Customer{

static Scanner in = new Scanner(System.in);
static ArrayList<Account> account = new ArrayList<>();

public static int bankMenu() {
        System.out.println("------------------------------------------------");
        System.out.println("Menu");
        System.out.println("1. Add Account.");
        System.out.println("2. Update Interest Rate.");
        System.out.println("3. Add Interest to Balance. ");
        System.out.println("4. Check Number of Accounts.");
        System.out.println("5. Search an Account. ");
        System.out.println("6. Deposit.");
        System.out.println("7. Withdraw.");
        System.out.println("8. Transfer Money.");
        System.out.println("9. Loan Policy");
		System.out.println("10. Exit the System.");
        System.out.println("------------------------------------------------");
        System.out.print("Enter your choice: ");
        return Integer.parseInt(in.nextLine());
    }
	
	
	public static void createNewAccount() {
        int type;
        do { 
            System.out.print("[Enter 1 for Savings account] [2 for Fixed account]: ");
            type = Integer.parseInt(in.nextLine());
            if (type == 1 || type == 2) {
                break;
            } else {
                System.out.println("Invalid choice.");
            }
        } while (true);
        System.out.print("Enter account number: ");
        String number = in.nextLine();
        System.out.print("Enter account name: ");
        String name = in.nextLine();
        double balance = 0;
        
        do {
            System.out.print("Enter balance: ");
            balance = Double.parseDouble(in.nextLine());
            if (balance > 100) {
                break;
            } else {
                System.out.println("Initial balance should be greater than 100.");
            }
        } while (true);
        
        if (type == 1) {
            System.out.print("Enter interest rate: ");
            double interest = Double.parseDouble(in.nextLine());
            account.add(new SavingsAccount(interest, number, name, balance));
        } else {
            account.add(new FixedAccount(number, name, balance));
        }
        System.out.println("New account created.");
    }

    public static void updateInterest() {
        System.out.print("Enter account number: ");
        String number = in.nextLine();
        int flag = 0;
        for (int i = 0; i < account.size(); i++) {
            if (number.equals(account.get(i).getAccountNo()) && account.get(i) instanceof SavingsAccount) {
                System.out.print("Enter a new interest rate: ");
                double interest = Double.parseDouble(in.nextLine());
                ((SavingsAccount) account.get(i)).setInterestRate(interest);
                System.out.println("Interest rate changed to: " + interest);
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
            System.out.println("account not found.");
        }
    }
	
    public static void addInterest() {
        System.out.print("Enter account number: ");
        String number = in.nextLine();
        int flag = 0;
        for (int i = 0; i < account.size(); i++) {
            if (number.equals(account.get(i).getAccountNo()) && account.get(i) instanceof SavingsAccount) {
                ((SavingsAccount) account.get(i)).updateBalanceAfterInterest();
                System.out.println("Balance has been updated.");
                System.out.println("------------------------------------------------");
                System.out.println(account.get(i).toString());
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
            System.out.println("account not found.");
        }
    }
	
	public static void numAccounts() {
        System.out.println("Current number of bank accounts: " + account.size());
    }
	
	public static void search() {
        System.out.print("Enter account number: ");
        String number = in.nextLine();
        int flag = 0;
        for (int i = 0; i < account.size(); i++) {
            if (number.equals(account.get(i).getAccountNo())) {
                System.out.println("Account found: ");
                System.out.println("------------------------------------------------");
                System.out.println(account.get(i).toString());
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
            System.out.println("account not found.");
        }
    }
	
    public static void goDeposit() {
        System.out.print("Enter account number: ");
        String number = in.nextLine();
        int flag = 0;
        for (int i = 0; i < account.size(); i++) {
            if (number.equals(account.get(i).getAccountNo())) {
                do {
                    System.out.print("Enter amount to be deposited: ");
                    double amount = Double.parseDouble(in.nextLine());
                    if (amount > 0) {
                        account.get(i).deposit(amount);
                        break;
                    } else {
                        System.out.println("Invalid amount.");
                    }
                } while (true);
                System.out.println("Deposit successful.");
                System.out.println("------------------------------------------------");
                System.out.println(account.get(i).toString());
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
            System.out.println("Account not found.");
        }
    }
	
	public static void goWithdraw() {
        System.out.print("Enter account number: ");
        String number = in.nextLine();
        int flag = 0;
        for (int i = 0; i < account.size(); i++) {
            if (number.equals(account.get(i).getAccountNo())) {
                do {
                    System.out.print("Enter amount to be withdrawn: ");
                    double amount = Double.parseDouble(in.nextLine());
                    if (amount > 0) {
                        if (account.get(i).withdraw(amount)) {
                            System.out.println("Withdrawal succcessful.");
                            break;
                        } else {
                            System.out.println("Insufficient funds.");
                            break;
                        }
                    } else {
                        System.out.println("Invalid amount.");
                    }
                } while (true);
                System.out.println("------------------------------------------------");
                System.out.println(account.get(i).toString());
                flag = 1;
                break;
            }
        }
        if (flag == 0) {
            System.out.println("account not found.");
        }
    }
	
	public static void transferMoney() {
        System.out.print("Enter account number transferring: ");
        String number1 = in.nextLine();
        System.out.print("Enter account number receiving:");
        String number2 = in.nextLine();
        int index1 = 0;
        int index2 = 0;
        int flag = 0;
        for (int i = 0; i < account.size(); i++) {
            if (number1.equals(account.get(i).getAccountNo())) {
                index1 = i;
                flag++;
            }
            if (number2.equals(account.get(i).getAccountNo())) {
                index2 = i;
                flag++;
            }
        }
        if (flag == 2) {
            System.out.print("Enter amount to transfer: ");
            double amount = Double.parseDouble(in.nextLine());
            if (account.get(index2).transferAmount(account.get(index1), amount)) {
                System.out.println("Money transfer succesful.");
                System.out.println("===============================================");
                System.out.println(account.get(index2).toString());
                System.out.println("===============================================");
                System.out.println(account.get(index1).toString());
            } else {
                System.out.println("Money transfer unsuccessful. Insuffiecient funds.");
            }
        } else {
            System.out.println("account not found.");
        }
    }
	
	public static void loanPolicy(){
		Loan L= new Loan();
		L.loanPolicy();
	}
	
    public static void main(String[] args) {
		
		
        System.out.println("===========(Welcome to Banking System)==========");
        do {
            switch (bankMenu()) {
                case 1:
                    createNewAccount();
                    break;
                case 2:
                    updateInterest();
                    break;
                case 3:
                    addInterest();
                    break;
                case 4:
                    numAccounts();
                    break;
                case 5:
                    search();
                    break;
                case 6:
                    goDeposit();
                    break;
                case 7:
                    goWithdraw();
                    break;
                case 8:
                    transferMoney();
                    break;
				case 9:
                    loanPolicy();
                    break;
                case 10:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } while (true);
    }
}