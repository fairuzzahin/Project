public class SavingsAccount  extends Account{
	private double interestRate;
	public  SavingsAccount(){
		System.out.println("Non-parameterized constructor called");
	}
	public  SavingsAccount( double interestRate,String accountNo,String accountholdername,double balance){
		super(accountNo,accountholdername, balance);
		this.interestRate=interestRate;
	}
	public boolean withdraw(double amount) {
        if(getBalance()-amount >= 100){
            setBalance(getBalance()-amount);
            return true;
        }
        return false;
    }
	 public double calcBalanceInterest(){
        return getBalance() * (this.interestRate/100);
    }
	public void updateBalanceAfterInterest(){
        setBalance(getBalance()+calcBalanceInterest());
    }
	public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
	public double getInterestRate() {
        return interestRate;
    }
	 public void displayinfo()
    {
        System.out.println("InterestRate :"+ interestRate);
    }
}