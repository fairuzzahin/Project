public interface Policy{
	
    public abstract void loanPolicy();
}