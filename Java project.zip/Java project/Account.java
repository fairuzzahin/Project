public  class Account{
	private String accountholdername;
	private String accountNo;
	private double balance;
	public Account(){
		System.out.println("Non-parameterized constructor called");
	}
	public Account(String accountholdername ,String accountNo,double balance){
        this. accountholdername= accountholdername;
		this.accountNo=accountNo;
		this. balance= balance;
	}  
	public boolean deposit(double amount){
        if(amount > 0 ){
            this.balance += amount;
            return true;
        }
        return false;
    }
    public boolean withdraw(double amount) {
        if(getBalance()-amount >= 100){
            setBalance(getBalance()-amount);
            return true;
        }
        return false;
    }
	public boolean transferAmount(Account account, double amount){
        if(account.balance - amount >=0){
            this.balance += amount;
            account.balance = account.balance - amount;
            return true;
        }
        return false;
    }
	
    public void setAccountholdername(String accountholdername){
        this.accountholdername= accountholdername;
    }
	public void setAccountNo(String accountNo){
		this.accountNo= accountNo;
	}
	public void setBalance(double balance){
	    this.balance= balance;
	}
    public  String getAccountholdername(){
        return   accountholdername;
    }
	public String getAccountNo(){
	    return accountNo;
	}
	public double getBalance(){
		return balance;
	}	
	
    public void displayInfo(){
        System.out.println("Accountholdername:"+ accountholdername);
        System.out.println("AccountNo:"+ accountNo);
        System.out.println("Balance:"+balance);
    }
	
	
	
}