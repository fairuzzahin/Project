public interface WithdrawInterface{
	
    public abstract boolean withdraw(double amount);
}