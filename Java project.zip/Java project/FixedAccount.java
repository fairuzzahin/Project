public class FixedAccount extends Account{
	private int tenureYear;
	public FixedAccount(){
		System.out.println("Non-parameterized constructor called");
	}
	public FixedAccount(String accountholdername,String accountNo,double balance){
		super(accountholdername,accountNo, balance);
 	}
    public boolean withdraw(double amount) {
        if(amount==getBalance()){
            return false;
        }
        setBalance(getBalance()-amount);
        return true;
    }

}