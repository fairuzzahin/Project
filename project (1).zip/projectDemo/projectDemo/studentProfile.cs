﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class studentProfile : Form
    {
        public studentProfile()
        {
            InitializeComponent();
        }

        private void studentProfile_Load(object sender, EventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlCommand sqlCmdUsers = new SqlCommand("SELECT * FROM users WHERE Id=@Id", sqlCon);

            sqlCmdUsers.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataReader users;

            users = sqlCmdUsers.ExecuteReader();

            while (users.Read())
            {
                name.Text = users["name"].ToString().Trim();
                studentId.Text = users["Id"].ToString().Trim();
                fatherName.Text = users["fatherName"].ToString().Trim();
                motherName.Text = users["motherName"].ToString().Trim();
                dob.Text = users["dob"].ToString().Trim();
                sex.Text = users["gender"].ToString().Trim();
                program.Text = users["program"].ToString().Trim();
                department.Text = users["department"].ToString().Trim();
                core.Text = users["core"].ToString().Trim();
                major.Text = users["major"].ToString().Trim();
                secondMajor.Text = users["secondMajor"].ToString().Trim();
                minor.Text = users["minor"].ToString().Trim();
                elective.Text = users["elective"].ToString().Trim();
                permanentAddress.Text = users["permanentAddress"].ToString().Trim();
                presentAddress.Text = users["presentAddress"].ToString().Trim();
                verifiedContact.Text = users["contactNumber"].ToString().Trim();
                verifiedEmail.Text = users["emailAddress"].ToString().Trim();
                nationality.Text = users["nationality"].ToString().Trim();
                religion.Text = users["religion"].ToString().Trim();
                maritalStatus.Text = users["maritalStatus"].ToString().Trim();
                bloodGroup.Text = users["bloodGroup"].ToString().Trim();
                admissionDate.Text = users["admissionDate"].ToString().Trim();
                cgpa.Text = users["cgpa"].ToString().Trim();
                credit.Text = users["credit"].ToString().Trim();
            }

            sqlCon.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
