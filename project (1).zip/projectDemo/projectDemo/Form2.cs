﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class Form2 : Form
    {

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width,int Height);

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        public Form2()
        {
            InitializeComponent();
            customizeMenu();
            this.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.Width, this.Height, 20, 20));
        }

        private void customizeMenu()
        {
            panel20.Visible = false;
            panel16.Visible = false;
            panel18.Visible = false;
            panel21.Visible = false;
            panel23.Visible = false;
        }

        private void hidesubMenu()
        {
            if (panel20.Visible == true)
                panel20.Visible = false;
            if (panel16.Visible == true)
                panel16.Visible = false;
            if (panel18.Visible == true)
                panel18.Visible = false;
            if (panel21.Visible == true)
                panel21.Visible = false;
            if (panel23.Visible == true)
                panel23.Visible = false;
        }

        private void showsubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hidesubMenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            showsubMenu(panel20);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openChildForm(new CourseResult());
            //code
            showsubMenu(panel20);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            openChildForm(new Registration());
            //code
            hidesubMenu();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            openChildForm(new Offered_Courses());
            //code
            hidesubMenu();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            showsubMenu(panel16);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            showsubMenu(panel18);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button22_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            showsubMenu(panel21);
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button24_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            showsubMenu(panel23);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            //code
            hidesubMenu();
        }

        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel24.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            openChildForm(new FirstPage());

            hidesubMenu();
        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void panel9_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.ShowDialog();
            this.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel12_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void panel12_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            openChildForm(new FirstPage());

            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlCommand sqlCmdUsersName = new SqlCommand("SELECT name FROM Users WHERE Id=@Id", sqlCon);
            sqlCmdUsersName.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataReader userName;

            userName = sqlCmdUsersName.ExecuteReader();

            while (userName.Read())
            {
                label1.Text = userName["name"].ToString();
            }
            sqlCon.Close();
        }

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void button27_Click(object sender, EventArgs e)
        {
            openChildForm(new CourseResult());

            hidesubMenu();
        }

        private void button28_Click(object sender, EventArgs e)
        {
            openChildForm(new Registration());
            //code
            hidesubMenu();
        }

        private void button29_Click(object sender, EventArgs e)
        {


            hidesubMenu();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            openChildForm(new studentProfile());

            hidesubMenu();
        }

        private void panel13_Click(object sender, EventArgs e)
        {
            openChildForm(new TeacherTNN());

            hidesubMenu();
        }

        private void panel10_Click(object sender, EventArgs e)
        {
            openChildForm(new StudentPasswordChange());

            hidesubMenu();
        }
    }
}
