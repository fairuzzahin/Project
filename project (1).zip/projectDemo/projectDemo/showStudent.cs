﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class showStudent : Form
    {
        public showStudent()
        {
            InitializeComponent();
        }

        private void showStudent_Load(object sender, EventArgs e)
        {
            studentDataShow("SELECT * FROM Users", dataGridView1);
        }

        public void studentDataShow(string q, DataGridView g)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter(q, sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            g.DataSource = dt;
            sqlCon.Close();
        }

        private void customTextBox1_MouseEnter(object sender, EventArgs e)
        {
            
        }

        private void customTextBox1_MouseLeave(object sender, EventArgs e)
        {
            
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "Search Here")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black;
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "Search Here";
                customTextBox1.ForeColor = Color.DimGray;

            }
        }

        public void searchStudent()
        {

        }

        public void search(DataGridView d, string q)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter(q, sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            d.DataSource = dt;
            sqlCon.Close();


            if (customTextBox1.Texts == "Search Here")
            {
                SqlDataAdapter sqldptAgain = new SqlDataAdapter("SELECT * FROM Users", sqlCon);

                sqlCon.Open();
                sqldptAgain.Fill(dt);
                d.DataSource = dt;
                sqlCon.Close();
            }
        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            search(dataGridView1, "SELECT * FROM Users WHERE Id LIKE '" + customTextBox1.Texts + "%'");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
