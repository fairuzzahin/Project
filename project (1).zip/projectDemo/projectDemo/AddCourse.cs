﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class AddCourse : Form
    {
        public AddCourse()
        {
            InitializeComponent();
            loadComboBox();
            SIIncrement();
        }

        public void loadComboBox()
        {
            comboBox("SELECT * FROM Program", "pId", "pName", comboBox8);
            comboBox("SELECT * FROM CourseName", "cId", "cName", comboBox12);
        }

        //function to auto increment id 
        public void SIIncrement()
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

            SqlDataAdapter sqladptr = new SqlDataAdapter("SELECT SI FROM CourseReg", sqlCon);

            DataTable dt = new DataTable();
            sqladptr.Fill(dt);

            if (dt.Rows.Count < 1)
            {
                customTextBox2.Texts = "1";
                customTextBox2.ForeColor = Color.Black;
            }
            else
            {
                SqlCommand sqladptr1 = new SqlCommand("SELECT MAX(SI) FROM CourseReg", sqlCon);
                sqlCon.Open();
                int a = Convert.ToInt32(sqladptr1.ExecuteScalar());
                sqlCon.Close();
                a = a + 1;
                customTextBox2.Texts = a.ToString();
                customTextBox2.ForeColor = Color.Black;
            }

        }

        //function for a comboBox to select data from database table
        public void comboBox(string q, string tc1, string tc2, ComboBox combobox)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

            SqlCommand sqlcom = new SqlCommand(q, sqlCon);

            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter(sqlcom);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);

            combobox.ValueMember = tc1;
            combobox.DisplayMember = tc2;
            combobox.DataSource = dt;

            sqlCon.Close();
        }

        //function for a dependent comboBox to select data from database table
        public void dComboBox(string q, string tc1, string tc2, string dtc1, ComboBox combobox, ComboBox dcombobox)
        {
            if (dcombobox.SelectedValue.ToString() != null)
            {
                SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                SqlCommand sqlcom = new SqlCommand(q, sqlCon);
                sqlCon.Open();
                sqlcom.Parameters.AddWithValue(dtc1, dcombobox.SelectedValue.ToString());
                SqlDataAdapter sqldpt = new SqlDataAdapter(sqlcom);

                DataTable dt = new DataTable();
                sqldpt.Fill(dt);

                combobox.ValueMember = tc1;
                combobox.DisplayMember = tc2;
                combobox.DataSource = dt;

                sqlCon.Close();
            }
        }

        //function to reset textBox and comboBox after insert a student 
        public void resertInsert()
        {
            loadComboBox();
            comboBox1.Text = "";
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (customTextBox2.ForeColor == Color.Black
                && comboBox8.ForeColor == Color.Black
                && comboBox12.ForeColor == Color.Black
                && comboBox1.ForeColor == Color.Black)
            {
                try
                {
                    SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                    sqlCon.Open();

                    String queryUsersAdd = "INSERT INTO CourseReg VALUES(@SI, @CourseName, @Section, @Faculty)";

                    SqlCommand sqlcmdAdd = new SqlCommand(queryUsersAdd, sqlCon);

                    sqlcmdAdd.CommandType = CommandType.Text;

                    sqlcmdAdd.Parameters.AddWithValue("@SI", customTextBox2.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@CourseName", comboBox12.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@Section", comboBox1.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@Faculty", comboBox8.Text.Trim());

                    int a = sqlcmdAdd.ExecuteNonQuery();

                    sqlCon.Close();

                    if (a > 0)
                    {
                        MessageBox.Show("Successful");
                        SIIncrement();
                        resertInsert();
                        tableShow();
                    }
                    else
                    {
                        MessageBox.Show("Not Successful");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Something Wrong");
                }
            }
            else
            {
                MessageBox.Show("Blank Field Must Fill Up");
            }
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            dComboBox("SELECT * FROM CourseName WHERE pId=@pId", "cId", "cName", "pId", comboBox12, comboBox8);
            if (comboBox8.Text == " SELECT ONE")
            {
                comboBox8.ForeColor = Color.DimGray;
            }
            else
                comboBox8.ForeColor = Color.Black;
        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox12.Text == " AT FIRST SELECT DEPARTMENT")
            {
                comboBox12.ForeColor = Color.DimGray;
            }
            else
                comboBox12.ForeColor = Color.Black;
        }

        private void customTextBox2__TextChanged(object sender, EventArgs e)
        {

        }

        private void customTextBox2_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("You can not change this field");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.ForeColor = Color.Black;
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            comboBox1.ForeColor = Color.Black;

        }

        public void tableShow()
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter("SELECT * FROM CourseReg", sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            dataGridView1.DataSource = dt;
            sqlCon.Close();
        }

        private void AddCourse_Load(object sender, EventArgs e)
        {
            tableShow();
        }

        public void search(DataGridView d, string q)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter(q, sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            d.DataSource = dt;
            sqlCon.Close();
        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            search(dataGridView1, "SELECT * FROM CourseReg WHERE CourseName LIKE '" + customTextBox1.Texts + "%'");
            if (customTextBox1.Texts == "" || customTextBox1.Texts == "Search Here")
            {
                tableShow();
            }
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "Search Here")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black;
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "Search Here";
                customTextBox1.ForeColor = Color.DimGray;

            }
        }
    }
}
