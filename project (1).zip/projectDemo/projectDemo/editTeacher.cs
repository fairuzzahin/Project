﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2.Custom;

namespace projectDemo
{
    public partial class editTeacher : Form
    {

        int ID;
        string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|" + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)" + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

        public editTeacher()
        {
            InitializeComponent();
            loadComboBox();
            button1.Enabled = false;
            loginBtn.Enabled = false;
        }

        public void loadComboBox()
        {
            comboBox("SELECT * FROM Gender", "gId", "gName", comboBox8);
            comboBox("SELECT * FROM Nationality", "nId", "nName", comboBox9);
            comboBox("SELECT * FROM Religion", "rId", "rName", comboBox10);
            comboBox("SELECT * FROM MaritalStatus", "mId", "mName", comboBox11);
            comboBox("SELECT * FROM BloodGroup", "bId", "bName", comboBox12);
            comboBox("SELECT * FROM Degree", "dId", "dName", comboBox1);
        }

        public void search(DataGridView d, string q)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter(q, sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            d.DataSource = dt;
            sqlCon.Close();
        }

        public void comboBox(string q, string tc1, string tc2, ComboBox combobox)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

            SqlCommand sqlcom = new SqlCommand(q, sqlCon);

            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter(sqlcom);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);

            combobox.ValueMember = tc1;
            combobox.DisplayMember = tc2;
            combobox.DataSource = dt;

            sqlCon.Close();
        }

        //function for a customTextBox when it is blank
        public void blankWarnimg(CustomTextBox textbox)
        {
            if (textbox.ForeColor == Color.DimGray)
            {
                textbox.ForeColor = Color.Red;
            }
        }

        //function for a textBox when it is blank
        public void blankWarnimg(TextBox textbox)
        {
            if (textbox.ForeColor == Color.DimGray)
            {
                textbox.ForeColor = Color.Red;
            }
        }

        //function for a comboBox when it is blank
        public void blankWarnimg(ComboBox combobox)
        {
            if (combobox.ForeColor == Color.DimGray)
            {
                combobox.ForeColor = Color.Red;
            }
        }

        public void aftrBlnkWrng(ComboBox combobox)
        {
            if (combobox.ForeColor == Color.Red)
            {
                combobox.ForeColor = Color.DimGray;
            }
        }

        //function for click enter on a customTextBox
        public void enterReset(CustomTextBox textbox, String s)
        {
            if (textbox.Texts == s)
            {
                textbox.Texts = "";
                textbox.ForeColor = Color.Black;
            }
        }

        //function for click leave from a customTextBox
        public void leaveReset(TextBox textbox, String s)
        {
            if (textbox.Text == "")
            {
                textbox.Text = s;
                textbox.ForeColor = Color.DimGray;
            }
        }

        //function for click enter on a textBox
        public void enterReset(TextBox textbox, String s)
        {
            if (textbox.Text == s)
            {
                textbox.Text = "";
                textbox.ForeColor = Color.Black;
            }
        }

        //function for click leave from a textBox
        public void leaveReset(CustomTextBox textbox, String s)
        {
            if (textbox.Texts == "")
            {
                textbox.Texts = s;
                textbox.ForeColor = Color.DimGray;
            }
        }

        public void resert()
        {
            customTextBox2.Texts = "";
            customTextBox3.Texts = "";
            customTextBox4.Texts = "";
            loadComboBox();
            textBox1.Text = "";
            textBox2.Text = "";
            customTextBox5.Texts = "";
            customTextBox6.Texts = "";
            customTextBox7.Texts = "";

            leaveReset(customTextBox2, "Enter Teacher Name");
            leaveReset(customTextBox3, "Enter Mother's Name");
            leaveReset(customTextBox4, "Enter Father's Name");
            leaveReset(customTextBox5, "Enter Contact Number");
            leaveReset(customTextBox6, "Enter Email Address");
            leaveReset(textBox1, "Enter Present Address");
            leaveReset(textBox2, "Enter Permanent Address");
            leaveReset(customTextBox7, "Enter Account Number");
        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            search(dataGridView1, "SELECT * FROM Teachers WHERE Id LIKE '" + customTextBox1.Texts + "%'");

            if (customTextBox1.Texts == "" || customTextBox1.Texts == "Search Here")
            {
                button1.Enabled = false;
                loginBtn.Enabled = false;
                resert();
            }
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "Search Here")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black;
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "Search Here";
                customTextBox1.ForeColor = Color.DimGray;

            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ID = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            customTextBox2.Texts = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            customTextBox3.Texts = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            customTextBox4.Texts = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            dateTimePicker1.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            comboBox8.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();
            customTextBox5.Texts = dataGridView1.Rows[e.RowIndex].Cells[9].Value.ToString();
            customTextBox6.Texts = dataGridView1.Rows[e.RowIndex].Cells[10].Value.ToString();
            comboBox9.Text = dataGridView1.Rows[e.RowIndex].Cells[11].Value.ToString();
            comboBox10.Text = dataGridView1.Rows[e.RowIndex].Cells[12].Value.ToString();
            comboBox11.Text = dataGridView1.Rows[e.RowIndex].Cells[13].Value.ToString();
            comboBox12.Text = dataGridView1.Rows[e.RowIndex].Cells[14].Value.ToString();
            comboBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[15].Value.ToString();
            customTextBox7.Texts = dataGridView1.Rows[e.RowIndex].Cells[16].Value.ToString();

            customTextBox2.ForeColor = Color.Black;
            customTextBox3.ForeColor = Color.Black;
            customTextBox4.ForeColor = Color.Black;
            customTextBox5.ForeColor = Color.Black;
            customTextBox6.ForeColor = Color.Black;
            textBox1.ForeColor = Color.Black;
            textBox2.ForeColor = Color.Black;
            comboBox1.ForeColor = Color.Black;
            comboBox8.ForeColor = Color.Black;
            comboBox9.ForeColor = Color.Black;
            comboBox10.ForeColor = Color.Black;
            comboBox11.ForeColor = Color.Black;
            comboBox12.ForeColor = Color.Black;
            customTextBox7.ForeColor = Color.Black;

            button1.Enabled = true;
            loginBtn.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                sqlCon.Open();

                SqlCommand sqlcmdAdd = new SqlCommand("delete from Teachers where Id='" + customTextBox1.Texts + "'", sqlCon);

                sqlcmdAdd.ExecuteNonQuery();

                sqlCon.Close();

                MessageBox.Show("Successful");
                search(dataGridView1, "SELECT * FROM Teachers WHERE Id LIKE '" + ID + "%'");
                button1.Enabled = false;
                loginBtn.Enabled = false;
                resert();
            }
            catch (Exception)
            {
                MessageBox.Show("Fail");
            }
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (customTextBox2.ForeColor == Color.Black
               && customTextBox3.ForeColor == Color.Black
               && customTextBox4.ForeColor == Color.Black
               && customTextBox5.ForeColor == Color.Black
               && customTextBox6.ForeColor == Color.Black
               && textBox1.ForeColor == Color.Black
               && textBox2.ForeColor == Color.Black
               && comboBox1.ForeColor == Color.Black
               && comboBox8.ForeColor == Color.Black
               && comboBox9.ForeColor == Color.Black
               && comboBox10.ForeColor == Color.Black
               && comboBox11.ForeColor == Color.Black
               && comboBox12.ForeColor == Color.Black
               && customTextBox7.ForeColor == Color.Black)
            {
                try
                {
                    SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                    sqlCon.Open();

                    SqlCommand sqlcmdAdd = new SqlCommand("update Teachers set name='" + customTextBox2.Texts + "', " +
                        "fatherName='" + customTextBox4.Texts + "', motherName='" + customTextBox3.Texts + "', " +
                        "dob='" + dateTimePicker1.Value.ToString() + "', gender='" + comboBox8.Text + "',  " +
                        "presentAddress='" + textBox1.Text + "', permanentAddress='" + textBox2.Text + "', " +
                        "contactNumber='" + customTextBox5.Texts + "', emailAddress='" + customTextBox6.Texts + "', " +
                        "nationality='" + comboBox9.Text + "', religion='" + comboBox10.Text + "', maritalStatus='" + comboBox11.Text + "', " +
                        "bloodGroup='" + comboBox12.Text + "', degree='" + comboBox1.Text + "', " +
                        "accountNumber='" + customTextBox7.Texts + "' where Id='" + ID + "'", sqlCon);

                    sqlcmdAdd.ExecuteNonQuery();

                    sqlCon.Close();

                    MessageBox.Show("Successful");
                    search(dataGridView1, "SELECT * FROM Teachers WHERE Id LIKE '" + customTextBox1.Texts + "%'");
                    button1.Enabled = false;
                    loginBtn.Enabled = false;
                    resert();

                }
                catch (Exception)
                {
                    MessageBox.Show("Fail");
                }
            }
            else
            {
                blankWarnimg(customTextBox2);
                blankWarnimg(customTextBox3);
                blankWarnimg(customTextBox4);
                blankWarnimg(customTextBox5);
                blankWarnimg(customTextBox6);
                blankWarnimg(customTextBox7);
                blankWarnimg(textBox1);
                blankWarnimg(textBox2);
                blankWarnimg(comboBox1);
                blankWarnimg(comboBox8);
                blankWarnimg(comboBox9);
                blankWarnimg(comboBox10);
                blankWarnimg(comboBox11);
                blankWarnimg(comboBox12);

                MessageBox.Show("Red Field Must Fill Up");
            }
        }

        private void customTextBox2_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox2, "Enter Teacher Name");
        }

        private void customTextBox2_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox2, "Enter Teacher Name");
        }

        private void customTextBox3_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox3, "Enter Mother's Name");
        }

        private void customTextBox3_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox3, "Enter Mother's Name");
        }

        private void customTextBox4_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox4, "Enter Father's Name");
        }

        private void customTextBox4_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox4, "Enter Father's Name");
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            enterReset(textBox1, "Enter Present Address");
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            leaveReset(textBox1, "Enter Present Address");
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            enterReset(textBox2, "Enter Permanent Address");
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            leaveReset(textBox2, "Enter Permanent Address");
        }

        private void customTextBox5_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox5, "Enter Contact Number");
        }

        private void customTextBox5_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox5, "Enter Contact Number");
            if (customTextBox5.Texts != "Enter Contact Number")
            {
                if (new Regex(@"^(?:\+?88|0088)?01[15-9]\d{8}$").IsMatch(customTextBox5.Texts))
                {
                    //MessageBox.Show("Mobile number is valide", "All information is required", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    customTextBox5.Focus();
                    MessageBox.Show("Mobile number is not valide", "All information is required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void customTextBox6_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox6, "Enter Email Address");
        }

        private void customTextBox6_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox6, "Enter Email Address");
            if (customTextBox6.Texts != "Enter Email Address")
            {
                if (Regex.IsMatch(customTextBox6.Texts, pattern) == false)
                {
                    customTextBox6.Focus();
                    MessageBox.Show("Email Address is not valide", "All information is required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox8.Text == " SELECT GENDER")
            {
                comboBox8.ForeColor = Color.DimGray;
            }
            else
                comboBox8.ForeColor = Color.Black;
        }

        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox9.Text == " SELECT NATIONALITY")
            {
                comboBox9.ForeColor = Color.DimGray;
            }
            else
                comboBox9.ForeColor = Color.Black;
        }

        private void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox10.Text == " SELECT RELIGION")
            {
                comboBox10.ForeColor = Color.DimGray;
            }
            else
                comboBox10.ForeColor = Color.Black;
        }

        private void comboBox11_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox11.Text == " SELECT MARITAL STATUS")
            {
                comboBox11.ForeColor = Color.DimGray;
            }
            else
                comboBox11.ForeColor = Color.Black;
        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox12.Text == " SELECT BLOOD GROUP")
            {
                comboBox12.ForeColor = Color.DimGray;
            }
            else
                comboBox12.ForeColor = Color.Black;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == " SELECT DEGREE")
            {
                comboBox1.ForeColor = Color.DimGray;
            }
            else
                comboBox1.ForeColor = Color.Black;
        }

        private void comboBox8_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox8);
        }

        private void comboBox9_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox9);
        }

        private void comboBox10_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox10);
        }

        private void comboBox11_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox11);
        }

        private void comboBox12_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox12);
        }

        private void comboBox1_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox1);
        }

        private void customTextBox7_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox7, "Enter Account Number");
        }

        private void customTextBox7_Leave(object sender, EventArgs e)
        {
            enterReset(customTextBox7, "Enter Account Number");
        }

        private void customTextBox2_FontChanged(object sender, EventArgs e)
        {

        }

        private void customTextBox3_EnabledChanged(object sender, EventArgs e)
        {

        }
    }
}
