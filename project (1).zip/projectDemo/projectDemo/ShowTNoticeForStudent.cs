﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class ShowTNoticeForStudent : Form
    {
        public ShowTNoticeForStudent()
        {
            InitializeComponent();
            tableShow();
        }

        public void tableShow()
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter("SELECT * FROM TNoticeForStudent", sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            dataGridView2.DataSource = dt;
            sqlCon.Close();
        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void ShowTNoticeForStudent_Load(object sender, EventArgs e)
        {
            tableShow();
        }
    }
}
