﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class StudentPasswordChange : Form
    {
        public string pass;
        public StudentPasswordChange()
        {
            InitializeComponent();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            
            if (customTextBox1.Texts == "" && customTextBox2.Texts == "" && customTextBox3.Texts == "")
            {
                label9.Visible = true;
                label9.Text = "The Current Password field is required.";
                customTextBox1.Focus();
                label2.Visible = true;
            }
            else if (customTextBox1.Texts == "" && customTextBox2.Texts == "")
            {
                label9.Visible = true;
                label9.Text = "The Current Password field is required.";
                customTextBox1.Focus();
                label2.Visible = true;
                label3.Visible = true;
            }
            else if (customTextBox1.Texts == "" && customTextBox3.Texts == "")
            {
                label9.Visible = true;
                label9.Text = "The Current Password field is required.";
                customTextBox1.Focus();
                label3.Visible = true;
            }
            else if (customTextBox2.Texts == "" && customTextBox3.Texts == "")
            {
                label2.Visible = true;
                customTextBox2.Focus();
            }
            else if (customTextBox1.Texts == "" && customTextBox2.Texts != customTextBox3.Texts)
            {
                label3.Visible = true;
                label9.Visible = true;
                label9.Text = "The Current Password field is required.";
                customTextBox1.Focus();
            }
            else if (customTextBox1.Texts == "" && customTextBox2.Texts == customTextBox3.Texts)
            {
                label9.Visible = true;
                customTextBox1.Focus();
            }
            else if (customTextBox1.Texts != "" && customTextBox2.Texts != customTextBox3.Texts)
            {
                label3.Visible = true;
                customTextBox3.Focus();
            }
            else if (customTextBox2.Texts == "")
            {
                label2.Visible = true;
                label3.Visible = true;
                customTextBox2.Focus();
            }
            else if (customTextBox3.Texts == "")
            {
                label3.Visible = true;
                customTextBox3.Focus();
            }
            else
            {

                SqlConnection sqlCon1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
                sqlCon1.Open();

                SqlCommand sqlCmdUsers = new SqlCommand("SELECT password FROM Users WHERE Id=@Id", sqlCon1);

                sqlCmdUsers.Parameters.AddWithValue("@Id", Form1.id);

                SqlDataReader users;

                users = sqlCmdUsers.ExecuteReader();

                while (users.Read())
                {
                    pass = users["password"].ToString().Trim();
                }

                sqlCon1.Close();


                if (pass != customTextBox1.Texts)
                {
                    label9.Visible = true;
                    customTextBox1.Focus();
                    label9.Text = "Current password is not correct.";
                    label3.Visible = false;
                }
                else if (!new Regex(@"^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$").IsMatch(customTextBox2.Texts))
                {
                    label2.Visible = true;
                    customTextBox2.Focus();
                    label2.Text = "Please check password policy.";
                }
                else
                {
                    try
                    {
                        SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                        sqlCon.Open();

                        SqlCommand sqlcmdAdd = new SqlCommand("update Users set password='" + customTextBox2.Texts + "' WHERE Id=@Id", sqlCon);

                        sqlcmdAdd.Parameters.AddWithValue("@Id", Form1.id);

                        sqlcmdAdd.ExecuteNonQuery();

                        sqlCon.Close();

                        MessageBox.Show("Successful");

                        customTextBox1.Texts = "";
                        customTextBox2.Texts = "";
                        customTextBox3.Texts = "";

                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Fail");
                    }
                }
            }

        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            label9.Visible = false;
        }

        private void customTextBox2__TextChanged(object sender, EventArgs e)
        {
            label2.Visible = false;
        }

        private void customTextBox3__TextChanged(object sender, EventArgs e)
        {
            label3.Visible = false;
        }
    }
}
