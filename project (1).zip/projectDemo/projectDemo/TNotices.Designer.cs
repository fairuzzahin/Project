﻿
namespace projectDemo
{
    partial class TNotices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel108 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel98 = new System.Windows.Forms.Panel();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel96 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel94 = new System.Windows.Forms.Panel();
            this.loginBtn = new System.Windows.Forms.Button();
            this.panel47 = new System.Windows.Forms.Panel();
            this.customTextBox1 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.panel49 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.customTextBox2 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.cgpa = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel131 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel151 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.loginDatabaseDataSet = new projectDemo.loginDatabaseDataSet();
            this.loginDatabaseDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.loginDatabaseDataSet1 = new projectDemo.loginDatabaseDataSet1();
            this.tNoticeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tNoticeTableAdapter = new projectDemo.loginDatabaseDataSet1TableAdapters.TNoticeTableAdapter();
            this.panel12.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel131.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDatabaseDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDatabaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tNoticeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(968, 10);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 573);
            this.panel4.TabIndex = 19;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 10);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 573);
            this.panel3.TabIndex = 18;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(978, 10);
            this.panel5.TabIndex = 17;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(132)))), ((int)(((byte)(250)))));
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(10, 10);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(958, 66);
            this.panel7.TabIndex = 20;
            // 
            // panel12
            // 
            this.panel12.AutoScroll = true;
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Controls.Add(this.panel31);
            this.panel12.Controls.Add(this.panel90);
            this.panel12.Controls.Add(this.loginBtn);
            this.panel12.Controls.Add(this.panel47);
            this.panel12.Controls.Add(this.panel18);
            this.panel12.Controls.Add(this.panel131);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel12.Location = new System.Drawing.Point(10, 76);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(432, 507);
            this.panel12.TabIndex = 21;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Controls.Add(this.panel35);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel31.Location = new System.Drawing.Point(0, 367);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(432, 35);
            this.panel31.TabIndex = 58;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.dateTimePicker1);
            this.panel32.Controls.Add(this.panel108);
            this.panel32.Controls.Add(this.panel89);
            this.panel32.Controls.Add(this.label2);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(120, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(312, 34);
            this.panel32.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.dateTimePicker1.Location = new System.Drawing.Point(7, 7);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(305, 29);
            this.dateTimePicker1.TabIndex = 10;
            // 
            // panel108
            // 
            this.panel108.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel108.Location = new System.Drawing.Point(0, 7);
            this.panel108.Name = "panel108";
            this.panel108.Size = new System.Drawing.Size(7, 27);
            this.panel108.TabIndex = 7;
            // 
            // panel89
            // 
            this.panel89.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel89.Location = new System.Drawing.Point(0, 0);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(312, 7);
            this.panel89.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 23);
            this.label2.TabIndex = 3;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label3);
            this.panel33.Controls.Add(this.panel34);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(120, 34);
            this.panel33.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(48, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 23);
            this.label3.TabIndex = 9;
            this.label3.Text = "Publish :  ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel34
            // 
            this.panel34.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(120, 7);
            this.panel34.TabIndex = 3;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel35.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel35.Location = new System.Drawing.Point(0, 34);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(432, 1);
            this.panel35.TabIndex = 1;
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.panel91);
            this.panel90.Controls.Add(this.panel92);
            this.panel90.Controls.Add(this.panel94);
            this.panel90.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel90.Location = new System.Drawing.Point(0, 122);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(432, 245);
            this.panel90.TabIndex = 57;
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.textBox1);
            this.panel91.Controls.Add(this.panel98);
            this.panel91.Controls.Add(this.panel97);
            this.panel91.Controls.Add(this.panel96);
            this.panel91.Controls.Add(this.panel95);
            this.panel91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel91.Location = new System.Drawing.Point(120, 0);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(312, 244);
            this.panel91.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.textBox1.ForeColor = System.Drawing.Color.DimGray;
            this.textBox1.Location = new System.Drawing.Point(7, 7);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(298, 230);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // panel98
            // 
            this.panel98.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel98.Location = new System.Drawing.Point(305, 7);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(7, 230);
            this.panel98.TabIndex = 7;
            // 
            // panel97
            // 
            this.panel97.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel97.Location = new System.Drawing.Point(0, 7);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(7, 230);
            this.panel97.TabIndex = 6;
            // 
            // panel96
            // 
            this.panel96.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel96.Location = new System.Drawing.Point(0, 237);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(312, 7);
            this.panel96.TabIndex = 5;
            // 
            // panel95
            // 
            this.panel95.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel95.Location = new System.Drawing.Point(0, 0);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(312, 7);
            this.panel95.TabIndex = 4;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.label27);
            this.panel92.Controls.Add(this.panel93);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel92.Location = new System.Drawing.Point(0, 0);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(120, 244);
            this.panel92.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Right;
            this.label27.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(69, 30);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 23);
            this.label27.TabIndex = 9;
            this.label27.Text = "Body : ";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel93
            // 
            this.panel93.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel93.Location = new System.Drawing.Point(0, 0);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(120, 30);
            this.panel93.TabIndex = 3;
            // 
            // panel94
            // 
            this.panel94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel94.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel94.Location = new System.Drawing.Point(0, 244);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(432, 1);
            this.panel94.TabIndex = 1;
            // 
            // loginBtn
            // 
            this.loginBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(127)))), ((int)(((byte)(175)))));
            this.loginBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginBtn.FlatAppearance.BorderSize = 0;
            this.loginBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.loginBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.loginBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginBtn.ForeColor = System.Drawing.Color.White;
            this.loginBtn.Location = new System.Drawing.Point(95, 426);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(209, 69);
            this.loginBtn.TabIndex = 56;
            this.loginBtn.Text = "PUBLISH";
            this.loginBtn.UseVisualStyleBackColor = false;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.customTextBox1);
            this.panel47.Controls.Add(this.panel49);
            this.panel47.Controls.Add(this.panel51);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel47.Location = new System.Drawing.Point(0, 87);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(432, 35);
            this.panel47.TabIndex = 34;
            // 
            // customTextBox1
            // 
            this.customTextBox1.BackColor = System.Drawing.Color.White;
            this.customTextBox1.BorderColor = System.Drawing.Color.White;
            this.customTextBox1.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox1.BorderSize = 0;
            this.customTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox1.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox1.Location = new System.Drawing.Point(120, 0);
            this.customTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox1.Multiline = false;
            this.customTextBox1.Name = "customTextBox1";
            this.customTextBox1.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox1.PasswordChar = false;
            this.customTextBox1.Size = new System.Drawing.Size(312, 38);
            this.customTextBox1.TabIndex = 5;
            this.customTextBox1.Tag = "1";
            this.customTextBox1.Texts = "";
            this.customTextBox1.UnderlinedStyle = false;
            this.customTextBox1._TextChanged += new System.EventHandler(this.customTextBox1__TextChanged);
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.label13);
            this.panel49.Controls.Add(this.panel50);
            this.panel49.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(120, 34);
            this.panel49.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Right;
            this.label13.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(52, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 23);
            this.label13.TabIndex = 9;
            this.label13.Text = "Subject : ";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel50
            // 
            this.panel50.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel50.Location = new System.Drawing.Point(0, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(120, 7);
            this.panel50.TabIndex = 3;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel51.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel51.Location = new System.Drawing.Point(0, 34);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(432, 1);
            this.panel51.TabIndex = 1;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Controls.Add(this.panel20);
            this.panel18.Controls.Add(this.panel42);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel18.Location = new System.Drawing.Point(0, 52);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(432, 35);
            this.panel18.TabIndex = 14;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.customTextBox2);
            this.panel19.Controls.Add(this.cgpa);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(120, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(312, 34);
            this.panel19.TabIndex = 5;
            // 
            // customTextBox2
            // 
            this.customTextBox2.BackColor = System.Drawing.Color.White;
            this.customTextBox2.BorderColor = System.Drawing.Color.White;
            this.customTextBox2.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox2.BorderSize = 0;
            this.customTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox2.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox2.Location = new System.Drawing.Point(0, 0);
            this.customTextBox2.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox2.Multiline = false;
            this.customTextBox2.Name = "customTextBox2";
            this.customTextBox2.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox2.PasswordChar = false;
            this.customTextBox2.Size = new System.Drawing.Size(312, 38);
            this.customTextBox2.TabIndex = 0;
            this.customTextBox2.Tag = "1";
            this.customTextBox2.Texts = "";
            this.customTextBox2.UnderlinedStyle = false;
            // 
            // cgpa
            // 
            this.cgpa.AutoSize = true;
            this.cgpa.Dock = System.Windows.Forms.DockStyle.Left;
            this.cgpa.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.cgpa.Location = new System.Drawing.Point(0, 0);
            this.cgpa.Name = "cgpa";
            this.cgpa.Size = new System.Drawing.Size(0, 23);
            this.cgpa.TabIndex = 3;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.label8);
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel20.Location = new System.Drawing.Point(0, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(120, 34);
            this.panel20.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Right;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(81, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 23);
            this.label8.TabIndex = 5;
            this.label8.Text = "S.N : ";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel21
            // 
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(120, 7);
            this.panel21.TabIndex = 4;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel42.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel42.Location = new System.Drawing.Point(0, 34);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(432, 1);
            this.panel42.TabIndex = 1;
            // 
            // panel131
            // 
            this.panel131.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(177)))), ((int)(((byte)(25)))));
            this.panel131.Controls.Add(this.label1);
            this.panel131.Controls.Add(this.panel151);
            this.panel131.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel131.Location = new System.Drawing.Point(0, 0);
            this.panel131.Name = "panel131";
            this.panel131.Size = new System.Drawing.Size(432, 52);
            this.panel131.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(120, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "Send Notice";
            // 
            // panel151
            // 
            this.panel151.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel151.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel151.Location = new System.Drawing.Point(0, 51);
            this.panel151.Name = "panel151";
            this.panel151.Size = new System.Drawing.Size(432, 1);
            this.panel151.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(442, 76);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(526, 507);
            this.dataGridView1.TabIndex = 22;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // loginDatabaseDataSet
            // 
            this.loginDatabaseDataSet.DataSetName = "loginDatabaseDataSet";
            this.loginDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loginDatabaseDataSetBindingSource
            // 
            this.loginDatabaseDataSetBindingSource.DataSource = this.loginDatabaseDataSet;
            this.loginDatabaseDataSetBindingSource.Position = 0;
            // 
            // loginDatabaseDataSet1
            // 
            this.loginDatabaseDataSet1.DataSetName = "loginDatabaseDataSet1";
            this.loginDatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tNoticeBindingSource
            // 
            this.tNoticeBindingSource.DataMember = "TNotice";
            this.tNoticeBindingSource.DataSource = this.loginDatabaseDataSet1;
            // 
            // tNoticeTableAdapter
            // 
            this.tNoticeTableAdapter.ClearBeforeFill = true;
            // 
            // TNotices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 583);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Name = "TNotices";
            this.Text = "TNotices";
            this.Load += new System.EventHandler(this.TNotices_Load);
            this.panel12.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel90.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.panel92.ResumeLayout(false);
            this.panel92.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel131.ResumeLayout(false);
            this.panel131.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDatabaseDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginDatabaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tNoticeBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox2;
        private System.Windows.Forms.Label cgpa;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel131;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel151;
        private System.Windows.Forms.Button loginBtn;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox1;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel108;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.DataGridView dataGridView1;
        private loginDatabaseDataSet loginDatabaseDataSet;
        private System.Windows.Forms.BindingSource loginDatabaseDataSetBindingSource;
        private loginDatabaseDataSet1 loginDatabaseDataSet1;
        private System.Windows.Forms.BindingSource tNoticeBindingSource;
        private loginDatabaseDataSet1TableAdapters.TNoticeTableAdapter tNoticeTableAdapter;
    }
}