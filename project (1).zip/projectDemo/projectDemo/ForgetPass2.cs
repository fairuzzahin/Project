﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class ForgetPass2 : Form
    {

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width, int Height);

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        public ForgetPass2()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            ForgetPass1 forgetPass1 = new ForgetPass1();
            forgetPass1.ShowDialog();
            this.Close();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {

            if (customTextBox2.Texts == "" && customTextBox3.Texts == "")
            {
                label7.Visible = true;
                customTextBox2.Focus();
            }
            else if (customTextBox2.Texts == "")
            {
                label7.Visible = true;
                label9.Visible = true;
                customTextBox2.Focus();
            }
            else if (customTextBox3.Texts == "")
            {
                label9.Visible = true;
                customTextBox3.Focus();
            }
        }

        private void customTextBox2__TextChanged(object sender, EventArgs e)
        {
            label7.Visible = false;
        }

        private void customTextBox3__TextChanged(object sender, EventArgs e)
        {
            label9.Visible = false;
        }

        private void panel12_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
