﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class TeacherTNN : Form
    {
        public TeacherTNN()
        {
            InitializeComponent();
        }

        private Form activeForm = null;

        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel10.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openChildForm(new TSF());


            button1.ForeColor = Color.Black;
            if (button2.ForeColor == Color.Black || button3.ForeColor == Color.Black)
            {
                button2.ForeColor = Color.LightSkyBlue;
                button3.ForeColor = Color.LightSkyBlue;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openChildForm(new Notes());

            button2.ForeColor = Color.Black;
            if (button1.ForeColor == Color.Black || button3.ForeColor == Color.Black)
            {
                button1.ForeColor = Color.LightSkyBlue;
                button3.ForeColor = Color.LightSkyBlue;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openChildForm(new ShowTNoticeForStudent());

            button3.ForeColor = Color.Black;
            if (button1.ForeColor == Color.Black || button2.ForeColor == Color.Black)
            {
                button1.ForeColor = Color.LightSkyBlue;
                button2.ForeColor = Color.LightSkyBlue;
            }
        }

        private void TeacherTNN_Load(object sender, EventArgs e)
        {
            openChildForm(new TSF());
        }
    }
}
