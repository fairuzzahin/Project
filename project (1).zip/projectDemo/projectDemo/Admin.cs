﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class Admin : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width, int Height);

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);
        public Admin()
        {
            InitializeComponent();
            customizeMenu();
        }

        private void customizeMenu()
        {
            panel20.Visible = false;
            panel11.Visible = false;
        }

        private void hidesubMenu()
        {
            if (panel20.Visible == true)
                panel20.Visible = false;
            if (panel11.Visible == true)
                panel11.Visible = false;
        }

        private void showsubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hidesubMenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel12_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            openChildForm(new addStudent());

            this.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.Width, this.Height, 20, 20));

            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlCommand sqlCmdAdminName = new SqlCommand("SELECT name FROM Admin WHERE Id=@Id", sqlCon);
            sqlCmdAdminName.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataReader adminName;

            adminName = sqlCmdAdminName.ExecuteReader();

            while (adminName.Read())
            {
                label2.Text = adminName["name"].ToString();
            }
            sqlCon.Close();
        }

        private void panel10_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.ShowDialog();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showsubMenu(panel20);
        }

        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel9.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openChildForm(new addStudent());

            hidesubMenu();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            openChildForm(new RemoveStudent());
            hidesubMenu();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            showsubMenu(panel11);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            openChildForm(new addTeacher());

            hidesubMenu();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openChildForm(new editTeacher());
            hidesubMenu();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            openChildForm(new showStudent());
            hidesubMenu();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            openChildForm(new showTeacher());
            hidesubMenu();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            openChildForm(new AddCourse()); 
            hidesubMenu();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            openChildForm(new TNotices());
            hidesubMenu();
        }
    }
}
