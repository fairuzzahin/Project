﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class CourseReg2 : Form
    {

        int ID;
        public CourseReg2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CourseReg2_Load(object sender, EventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlCommand sqlCmdUsers = new SqlCommand("SELECT * FROM users WHERE Id=@Id", sqlCon);

            sqlCmdUsers.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataReader users;

            users = sqlCmdUsers.ExecuteReader();

            while (users.Read())
            {
                label5.Text = users["program"].ToString().Trim();
            }

            sqlCon.Close();

            CourseShow("SELECT * FROM CourseReg WHERE Faculty=@Faculty", dataGridView1);
            SelectedShow("SELECT * FROM SelectedCourse WHERE Id=@Id", dataGridView2);

        }

        public void CourseShow(string q, DataGridView g)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlCommand sqlCmdUsers = new SqlCommand(q, sqlCon);

            sqlCmdUsers.Parameters.AddWithValue("@Faculty", label5.Text);

            SqlDataAdapter sqldpt = new SqlDataAdapter(sqlCmdUsers);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            g.DataSource = dt;
            sqlCon.Close();
        }

        public void SelectedShow(string q, DataGridView g)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlCommand sqlCmdUsers = new SqlCommand(q, sqlCon);

            sqlCmdUsers.Parameters.AddWithValue("@Id", Form1.id);

            SqlDataAdapter sqldpt = new SqlDataAdapter(sqlCmdUsers);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            g.DataSource = dt;
            sqlCon.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (customTextBox2.ForeColor == Color.Black
              && customTextBox1.ForeColor == Color.Black)
            {
                try
                {
                    SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                    sqlCon.Open();

                    String queryUsersAdd = "INSERT INTO SelectedCourse VALUES(@CourseName, @Section, @Id)";

                    SqlCommand sqlcmdAdd = new SqlCommand(queryUsersAdd, sqlCon);

                    sqlcmdAdd.CommandType = CommandType.Text;

                    sqlcmdAdd.Parameters.AddWithValue("@CourseName", customTextBox2.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@Section", customTextBox1.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@Id", Form1.id);

                    int a = sqlcmdAdd.ExecuteNonQuery();

                    sqlCon.Close();

                    if (a > 0)
                    {
                        MessageBox.Show("Successful");
                    }
                    else
                    {
                        MessageBox.Show("Not Successful");
                    }

                }
                catch (Exception)
                {
                    MessageBox.Show("Fail");
                }
            }
            else
            {
                MessageBox.Show("Red Field Must Fill Up");
            }

            SelectedShow("SELECT * FROM SelectedCourse WHERE Id=@Id", dataGridView2);

        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            ID = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            customTextBox2.Texts = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            customTextBox1.Texts = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();

            customTextBox2.ForeColor = Color.Black;
            customTextBox1.ForeColor = Color.Black;
        }
    }
}
