﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDemo
{
    public partial class TNoticeForStudent : Form
    {
        public TNoticeForStudent()
        {
            InitializeComponent();
            SIIncrement();
        }

        public void SIIncrement()
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

            SqlDataAdapter sqladptr = new SqlDataAdapter("SELECT Id FROM TNoticeForStudent", sqlCon);

            DataTable dt = new DataTable();
            sqladptr.Fill(dt);

            if (dt.Rows.Count < 1)
            {
                customTextBox2.Texts = "1";
                customTextBox2.ForeColor = Color.Black;
            }
            else
            {
                SqlCommand sqladptr1 = new SqlCommand("SELECT MAX(Id) FROM TNoticeForStudent", sqlCon);
                sqlCon.Open();
                int a = Convert.ToInt32(sqladptr1.ExecuteScalar());
                sqlCon.Close();
                a = a + 1;
                customTextBox2.Texts = a.ToString();
                customTextBox2.ForeColor = Color.Black;
            }

        }

        public void tableShow()
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");
            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter("SELECT * FROM TNoticeForStudent", sqlCon);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);
            dataGridView1.DataSource = dt;
            sqlCon.Close();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (customTextBox2.ForeColor == Color.Black
                && customTextBox1.ForeColor == Color.Black
                && textBox1.ForeColor == Color.Black
                && customTextBox1.Texts != ""
                && textBox1.Text != "")
            {
                try
                {
                    SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                    sqlCon.Open();

                    String queryUsersAdd = "INSERT INTO TNoticeForStudent VALUES(@Id, @Sub, @Body, @Date)";

                    SqlCommand sqlcmdAdd = new SqlCommand(queryUsersAdd, sqlCon);

                    sqlcmdAdd.CommandType = CommandType.Text;

                    sqlcmdAdd.Parameters.AddWithValue("@Id", customTextBox2.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@Sub", customTextBox1.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@Body", textBox1.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@Date", dateTimePicker1.Value.ToString().Trim());

                    int a = sqlcmdAdd.ExecuteNonQuery();

                    sqlCon.Close();

                    if (a > 0)
                    {
                        MessageBox.Show("Successful");
                        SIIncrement();
                        customTextBox1.Texts = "";
                        textBox1.Text = "";
                        tableShow();
                    }
                    else
                    {
                        MessageBox.Show("Not Successful");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Something Wrong");
                }
            }
            else
            {
                MessageBox.Show("Blank Field Must Fill Up");
            }
        }

        private void TNoticeForStudent_Load(object sender, EventArgs e)
        {
            tableShow();
        }

        private void customTextBox2__TextChanged(object sender, EventArgs e)
        {
            
        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {
            customTextBox1.ForeColor = Color.Black;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Black;
        }
    }
}
