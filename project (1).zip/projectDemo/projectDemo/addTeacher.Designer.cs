﻿
namespace projectDemo
{
    partial class addTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel43 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel44 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.customTextBox7 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel144 = new System.Windows.Forms.Panel();
            this.panel145 = new System.Windows.Forms.Panel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.panel146 = new System.Windows.Forms.Panel();
            this.panel147 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.panel148 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.panel149 = new System.Windows.Forms.Panel();
            this.panel150 = new System.Windows.Forms.Panel();
            this.panel138 = new System.Windows.Forms.Panel();
            this.panel139 = new System.Windows.Forms.Panel();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.panel140 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.panel141 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.panel142 = new System.Windows.Forms.Panel();
            this.panel143 = new System.Windows.Forms.Panel();
            this.panel132 = new System.Windows.Forms.Panel();
            this.panel133 = new System.Windows.Forms.Panel();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.panel134 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.panel135 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.panel136 = new System.Windows.Forms.Panel();
            this.panel137 = new System.Windows.Forms.Panel();
            this.panel125 = new System.Windows.Forms.Panel();
            this.panel126 = new System.Windows.Forms.Panel();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.panel127 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel128 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.panel129 = new System.Windows.Forms.Panel();
            this.panel130 = new System.Windows.Forms.Panel();
            this.panel119 = new System.Windows.Forms.Panel();
            this.panel120 = new System.Windows.Forms.Panel();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.panel121 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel122 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.panel123 = new System.Windows.Forms.Panel();
            this.panel124 = new System.Windows.Forms.Panel();
            this.panel114 = new System.Windows.Forms.Panel();
            this.panel115 = new System.Windows.Forms.Panel();
            this.customTextBox6 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.panel116 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.panel117 = new System.Windows.Forms.Panel();
            this.panel118 = new System.Windows.Forms.Panel();
            this.panel109 = new System.Windows.Forms.Panel();
            this.panel110 = new System.Windows.Forms.Panel();
            this.customTextBox5 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.panel111 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.panel112 = new System.Windows.Forms.Panel();
            this.panel113 = new System.Windows.Forms.Panel();
            this.panel99 = new System.Windows.Forms.Panel();
            this.panel100 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel101 = new System.Windows.Forms.Panel();
            this.panel102 = new System.Windows.Forms.Panel();
            this.panel103 = new System.Windows.Forms.Panel();
            this.panel104 = new System.Windows.Forms.Panel();
            this.panel105 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.panel106 = new System.Windows.Forms.Panel();
            this.panel107 = new System.Windows.Forms.Panel();
            this.panel90 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel98 = new System.Windows.Forms.Panel();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel96 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel92 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel94 = new System.Windows.Forms.Panel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.customTextBox9 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel60 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.panel88 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel49 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel108 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.customTextBox4 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.program = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.customTextBox3 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.credit = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.customTextBox2 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.cgpa = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.customTextBox1 = new WindowsFormsApp2.Custom.CustomTextBox();
            this.studentId = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel131 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.loginBtn = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel144.SuspendLayout();
            this.panel145.SuspendLayout();
            this.panel148.SuspendLayout();
            this.panel138.SuspendLayout();
            this.panel139.SuspendLayout();
            this.panel141.SuspendLayout();
            this.panel132.SuspendLayout();
            this.panel133.SuspendLayout();
            this.panel135.SuspendLayout();
            this.panel125.SuspendLayout();
            this.panel126.SuspendLayout();
            this.panel128.SuspendLayout();
            this.panel119.SuspendLayout();
            this.panel120.SuspendLayout();
            this.panel122.SuspendLayout();
            this.panel114.SuspendLayout();
            this.panel115.SuspendLayout();
            this.panel116.SuspendLayout();
            this.panel109.SuspendLayout();
            this.panel110.SuspendLayout();
            this.panel111.SuspendLayout();
            this.panel99.SuspendLayout();
            this.panel100.SuspendLayout();
            this.panel105.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel58.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(834, 1055);
            this.panel1.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(10, 10);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(814, 1035);
            this.panel6.TabIndex = 8;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(814, 966);
            this.panel8.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.AutoScroll = true;
            this.panel9.Controls.Add(this.panel41);
            this.panel9.Controls.Add(this.panel36);
            this.panel9.Controls.Add(this.panel144);
            this.panel9.Controls.Add(this.panel138);
            this.panel9.Controls.Add(this.panel132);
            this.panel9.Controls.Add(this.panel125);
            this.panel9.Controls.Add(this.panel119);
            this.panel9.Controls.Add(this.panel114);
            this.panel9.Controls.Add(this.panel109);
            this.panel9.Controls.Add(this.panel99);
            this.panel9.Controls.Add(this.panel90);
            this.panel9.Controls.Add(this.panel58);
            this.panel9.Controls.Add(this.panel47);
            this.panel9.Controls.Add(this.panel31);
            this.panel9.Controls.Add(this.panel26);
            this.panel9.Controls.Add(this.panel21);
            this.panel9.Controls.Add(this.panel16);
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(814, 966);
            this.panel9.TabIndex = 16;
            // 
            // panel41
            // 
            this.panel41.Controls.Add(this.panel42);
            this.panel41.Controls.Add(this.panel44);
            this.panel41.Controls.Add(this.panel46);
            this.panel41.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel41.Location = new System.Drawing.Point(0, 739);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(814, 35);
            this.panel41.TabIndex = 57;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.comboBox1);
            this.panel42.Controls.Add(this.panel43);
            this.panel42.Controls.Add(this.label7);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel42.Location = new System.Drawing.Point(120, 0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(694, 34);
            this.panel42.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox1.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(0, 3);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(694, 30);
            this.comboBox1.TabIndex = 0;
            // 
            // panel43
            // 
            this.panel43.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel43.Location = new System.Drawing.Point(0, 0);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(694, 3);
            this.panel43.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Left;
            this.label7.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 23);
            this.label7.TabIndex = 3;
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.label9);
            this.panel44.Controls.Add(this.panel45);
            this.panel44.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel44.Location = new System.Drawing.Point(0, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(120, 34);
            this.panel44.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Right;
            this.label9.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(56, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 23);
            this.label9.TabIndex = 9;
            this.label9.Text = "Degree : ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel45
            // 
            this.panel45.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel45.Location = new System.Drawing.Point(0, 0);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(120, 7);
            this.panel45.TabIndex = 3;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel46.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel46.Location = new System.Drawing.Point(0, 34);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(814, 1);
            this.panel46.TabIndex = 1;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.panel37);
            this.panel36.Controls.Add(this.panel38);
            this.panel36.Controls.Add(this.panel40);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel36.Location = new System.Drawing.Point(0, 704);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(814, 35);
            this.panel36.TabIndex = 56;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.customTextBox7);
            this.panel37.Controls.Add(this.label4);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel37.Location = new System.Drawing.Point(120, 0);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(694, 34);
            this.panel37.TabIndex = 5;
            // 
            // customTextBox7
            // 
            this.customTextBox7.BackColor = System.Drawing.Color.White;
            this.customTextBox7.BorderColor = System.Drawing.Color.White;
            this.customTextBox7.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox7.BorderSize = 0;
            this.customTextBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox7.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox7.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox7.Location = new System.Drawing.Point(0, 0);
            this.customTextBox7.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox7.Multiline = false;
            this.customTextBox7.Name = "customTextBox7";
            this.customTextBox7.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox7.PasswordChar = false;
            this.customTextBox7.Size = new System.Drawing.Size(694, 38);
            this.customTextBox7.TabIndex = 0;
            this.customTextBox7.Tag = "1";
            this.customTextBox7.Texts = "Enter Account Number";
            this.customTextBox7.UnderlinedStyle = false;
            this.customTextBox7.Enter += new System.EventHandler(this.customTextBox7_Enter);
            this.customTextBox7.Leave += new System.EventHandler(this.customTextBox7_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 23);
            this.label4.TabIndex = 3;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.label5);
            this.panel38.Controls.Add(this.panel39);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel38.Location = new System.Drawing.Point(0, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(120, 34);
            this.panel38.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(-4, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 23);
            this.label5.TabIndex = 9;
            this.label5.Text = "Account Number : ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel39
            // 
            this.panel39.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(120, 7);
            this.panel39.TabIndex = 3;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel40.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel40.Location = new System.Drawing.Point(0, 34);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(814, 1);
            this.panel40.TabIndex = 1;
            // 
            // panel144
            // 
            this.panel144.Controls.Add(this.panel145);
            this.panel144.Controls.Add(this.panel148);
            this.panel144.Controls.Add(this.panel150);
            this.panel144.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel144.Location = new System.Drawing.Point(0, 669);
            this.panel144.Name = "panel144";
            this.panel144.Size = new System.Drawing.Size(814, 35);
            this.panel144.TabIndex = 55;
            // 
            // panel145
            // 
            this.panel145.Controls.Add(this.dateTimePicker2);
            this.panel145.Controls.Add(this.panel146);
            this.panel145.Controls.Add(this.panel147);
            this.panel145.Controls.Add(this.label40);
            this.panel145.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel145.Location = new System.Drawing.Point(120, 0);
            this.panel145.Name = "panel145";
            this.panel145.Size = new System.Drawing.Size(694, 34);
            this.panel145.TabIndex = 5;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.dateTimePicker2.Location = new System.Drawing.Point(7, 7);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(687, 29);
            this.dateTimePicker2.TabIndex = 10;
            // 
            // panel146
            // 
            this.panel146.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel146.Location = new System.Drawing.Point(0, 7);
            this.panel146.Name = "panel146";
            this.panel146.Size = new System.Drawing.Size(7, 27);
            this.panel146.TabIndex = 7;
            // 
            // panel147
            // 
            this.panel147.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel147.Location = new System.Drawing.Point(0, 0);
            this.panel147.Name = "panel147";
            this.panel147.Size = new System.Drawing.Size(694, 7);
            this.panel147.TabIndex = 5;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Left;
            this.label40.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label40.Location = new System.Drawing.Point(0, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(0, 23);
            this.label40.TabIndex = 3;
            // 
            // panel148
            // 
            this.panel148.Controls.Add(this.label41);
            this.panel148.Controls.Add(this.panel149);
            this.panel148.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel148.Location = new System.Drawing.Point(0, 0);
            this.panel148.Name = "panel148";
            this.panel148.Size = new System.Drawing.Size(120, 34);
            this.panel148.TabIndex = 4;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Right;
            this.label41.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(17, 7);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(103, 23);
            this.label41.TabIndex = 9;
            this.label41.Text = "Joining Date :  ";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel149
            // 
            this.panel149.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel149.Location = new System.Drawing.Point(0, 0);
            this.panel149.Name = "panel149";
            this.panel149.Size = new System.Drawing.Size(120, 7);
            this.panel149.TabIndex = 3;
            // 
            // panel150
            // 
            this.panel150.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel150.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel150.Location = new System.Drawing.Point(0, 34);
            this.panel150.Name = "panel150";
            this.panel150.Size = new System.Drawing.Size(814, 1);
            this.panel150.TabIndex = 1;
            // 
            // panel138
            // 
            this.panel138.Controls.Add(this.panel139);
            this.panel138.Controls.Add(this.panel141);
            this.panel138.Controls.Add(this.panel143);
            this.panel138.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel138.Location = new System.Drawing.Point(0, 634);
            this.panel138.Name = "panel138";
            this.panel138.Size = new System.Drawing.Size(814, 35);
            this.panel138.TabIndex = 54;
            // 
            // panel139
            // 
            this.panel139.Controls.Add(this.comboBox12);
            this.panel139.Controls.Add(this.panel140);
            this.panel139.Controls.Add(this.label38);
            this.panel139.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel139.Location = new System.Drawing.Point(120, 0);
            this.panel139.Name = "panel139";
            this.panel139.Size = new System.Drawing.Size(694, 34);
            this.panel139.TabIndex = 5;
            // 
            // comboBox12
            // 
            this.comboBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox12.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox12.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(0, 3);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(694, 30);
            this.comboBox12.TabIndex = 0;
            this.comboBox12.SelectedIndexChanged += new System.EventHandler(this.comboBox12_SelectedIndexChanged);
            this.comboBox12.Enter += new System.EventHandler(this.comboBox12_Enter);
            // 
            // panel140
            // 
            this.panel140.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel140.Location = new System.Drawing.Point(0, 0);
            this.panel140.Name = "panel140";
            this.panel140.Size = new System.Drawing.Size(694, 3);
            this.panel140.TabIndex = 4;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Left;
            this.label38.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label38.Location = new System.Drawing.Point(0, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(0, 23);
            this.label38.TabIndex = 3;
            // 
            // panel141
            // 
            this.panel141.Controls.Add(this.label39);
            this.panel141.Controls.Add(this.panel142);
            this.panel141.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel141.Location = new System.Drawing.Point(0, 0);
            this.panel141.Name = "panel141";
            this.panel141.Size = new System.Drawing.Size(120, 34);
            this.panel141.TabIndex = 4;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Right;
            this.label39.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(24, 7);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(96, 23);
            this.label39.TabIndex = 9;
            this.label39.Text = "Blood Group : ";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel142
            // 
            this.panel142.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel142.Location = new System.Drawing.Point(0, 0);
            this.panel142.Name = "panel142";
            this.panel142.Size = new System.Drawing.Size(120, 7);
            this.panel142.TabIndex = 3;
            // 
            // panel143
            // 
            this.panel143.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel143.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel143.Location = new System.Drawing.Point(0, 34);
            this.panel143.Name = "panel143";
            this.panel143.Size = new System.Drawing.Size(814, 1);
            this.panel143.TabIndex = 1;
            // 
            // panel132
            // 
            this.panel132.Controls.Add(this.panel133);
            this.panel132.Controls.Add(this.panel135);
            this.panel132.Controls.Add(this.panel137);
            this.panel132.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel132.Location = new System.Drawing.Point(0, 599);
            this.panel132.Name = "panel132";
            this.panel132.Size = new System.Drawing.Size(814, 35);
            this.panel132.TabIndex = 53;
            // 
            // panel133
            // 
            this.panel133.Controls.Add(this.comboBox11);
            this.panel133.Controls.Add(this.panel134);
            this.panel133.Controls.Add(this.label36);
            this.panel133.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel133.Location = new System.Drawing.Point(120, 0);
            this.panel133.Name = "panel133";
            this.panel133.Size = new System.Drawing.Size(694, 34);
            this.panel133.TabIndex = 5;
            // 
            // comboBox11
            // 
            this.comboBox11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox11.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox11.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Location = new System.Drawing.Point(0, 3);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(694, 30);
            this.comboBox11.TabIndex = 0;
            this.comboBox11.SelectedIndexChanged += new System.EventHandler(this.comboBox11_SelectedIndexChanged);
            this.comboBox11.Enter += new System.EventHandler(this.comboBox11_Enter);
            // 
            // panel134
            // 
            this.panel134.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel134.Location = new System.Drawing.Point(0, 0);
            this.panel134.Name = "panel134";
            this.panel134.Size = new System.Drawing.Size(694, 3);
            this.panel134.TabIndex = 4;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Left;
            this.label36.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label36.Location = new System.Drawing.Point(0, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(0, 23);
            this.label36.TabIndex = 3;
            // 
            // panel135
            // 
            this.panel135.Controls.Add(this.label37);
            this.panel135.Controls.Add(this.panel136);
            this.panel135.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel135.Location = new System.Drawing.Point(0, 0);
            this.panel135.Name = "panel135";
            this.panel135.Size = new System.Drawing.Size(120, 34);
            this.panel135.TabIndex = 4;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Right;
            this.label37.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(8, 7);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(112, 23);
            this.label37.TabIndex = 9;
            this.label37.Text = "Marital Status : ";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel136
            // 
            this.panel136.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel136.Location = new System.Drawing.Point(0, 0);
            this.panel136.Name = "panel136";
            this.panel136.Size = new System.Drawing.Size(120, 7);
            this.panel136.TabIndex = 3;
            // 
            // panel137
            // 
            this.panel137.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel137.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel137.Location = new System.Drawing.Point(0, 34);
            this.panel137.Name = "panel137";
            this.panel137.Size = new System.Drawing.Size(814, 1);
            this.panel137.TabIndex = 1;
            // 
            // panel125
            // 
            this.panel125.Controls.Add(this.panel126);
            this.panel125.Controls.Add(this.panel128);
            this.panel125.Controls.Add(this.panel130);
            this.panel125.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel125.Location = new System.Drawing.Point(0, 564);
            this.panel125.Name = "panel125";
            this.panel125.Size = new System.Drawing.Size(814, 35);
            this.panel125.TabIndex = 52;
            // 
            // panel126
            // 
            this.panel126.Controls.Add(this.comboBox10);
            this.panel126.Controls.Add(this.panel127);
            this.panel126.Controls.Add(this.label34);
            this.panel126.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel126.Location = new System.Drawing.Point(120, 0);
            this.panel126.Name = "panel126";
            this.panel126.Size = new System.Drawing.Size(694, 34);
            this.panel126.TabIndex = 5;
            // 
            // comboBox10
            // 
            this.comboBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox10.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox10.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(0, 3);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(694, 30);
            this.comboBox10.TabIndex = 0;
            this.comboBox10.SelectedIndexChanged += new System.EventHandler(this.comboBox10_SelectedIndexChanged);
            this.comboBox10.Enter += new System.EventHandler(this.comboBox10_Enter);
            // 
            // panel127
            // 
            this.panel127.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel127.Location = new System.Drawing.Point(0, 0);
            this.panel127.Name = "panel127";
            this.panel127.Size = new System.Drawing.Size(694, 3);
            this.panel127.TabIndex = 4;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Left;
            this.label34.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label34.Location = new System.Drawing.Point(0, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(0, 23);
            this.label34.TabIndex = 3;
            // 
            // panel128
            // 
            this.panel128.Controls.Add(this.label35);
            this.panel128.Controls.Add(this.panel129);
            this.panel128.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel128.Location = new System.Drawing.Point(0, 0);
            this.panel128.Name = "panel128";
            this.panel128.Size = new System.Drawing.Size(120, 34);
            this.panel128.TabIndex = 4;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Right;
            this.label35.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(48, 7);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(72, 23);
            this.label35.TabIndex = 9;
            this.label35.Text = "Religion : ";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel129
            // 
            this.panel129.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel129.Location = new System.Drawing.Point(0, 0);
            this.panel129.Name = "panel129";
            this.panel129.Size = new System.Drawing.Size(120, 7);
            this.panel129.TabIndex = 3;
            // 
            // panel130
            // 
            this.panel130.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel130.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel130.Location = new System.Drawing.Point(0, 34);
            this.panel130.Name = "panel130";
            this.panel130.Size = new System.Drawing.Size(814, 1);
            this.panel130.TabIndex = 1;
            // 
            // panel119
            // 
            this.panel119.Controls.Add(this.panel120);
            this.panel119.Controls.Add(this.panel122);
            this.panel119.Controls.Add(this.panel124);
            this.panel119.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel119.Location = new System.Drawing.Point(0, 529);
            this.panel119.Name = "panel119";
            this.panel119.Size = new System.Drawing.Size(814, 35);
            this.panel119.TabIndex = 51;
            // 
            // panel120
            // 
            this.panel120.Controls.Add(this.comboBox9);
            this.panel120.Controls.Add(this.panel121);
            this.panel120.Controls.Add(this.label32);
            this.panel120.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel120.Location = new System.Drawing.Point(120, 0);
            this.panel120.Name = "panel120";
            this.panel120.Size = new System.Drawing.Size(694, 34);
            this.panel120.TabIndex = 5;
            // 
            // comboBox9
            // 
            this.comboBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox9.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox9.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(0, 3);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(694, 30);
            this.comboBox9.TabIndex = 0;
            this.comboBox9.SelectedIndexChanged += new System.EventHandler(this.comboBox9_SelectedIndexChanged);
            this.comboBox9.Enter += new System.EventHandler(this.comboBox9_Enter);
            // 
            // panel121
            // 
            this.panel121.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel121.Location = new System.Drawing.Point(0, 0);
            this.panel121.Name = "panel121";
            this.panel121.Size = new System.Drawing.Size(694, 3);
            this.panel121.TabIndex = 4;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Left;
            this.label32.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label32.Location = new System.Drawing.Point(0, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(0, 23);
            this.label32.TabIndex = 3;
            // 
            // panel122
            // 
            this.panel122.Controls.Add(this.label33);
            this.panel122.Controls.Add(this.panel123);
            this.panel122.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel122.Location = new System.Drawing.Point(0, 0);
            this.panel122.Name = "panel122";
            this.panel122.Size = new System.Drawing.Size(120, 34);
            this.panel122.TabIndex = 4;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Right;
            this.label33.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(31, 7);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(89, 23);
            this.label33.TabIndex = 9;
            this.label33.Text = "Nationality : ";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel123
            // 
            this.panel123.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel123.Location = new System.Drawing.Point(0, 0);
            this.panel123.Name = "panel123";
            this.panel123.Size = new System.Drawing.Size(120, 7);
            this.panel123.TabIndex = 3;
            // 
            // panel124
            // 
            this.panel124.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel124.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel124.Location = new System.Drawing.Point(0, 34);
            this.panel124.Name = "panel124";
            this.panel124.Size = new System.Drawing.Size(814, 1);
            this.panel124.TabIndex = 1;
            // 
            // panel114
            // 
            this.panel114.Controls.Add(this.panel115);
            this.panel114.Controls.Add(this.panel116);
            this.panel114.Controls.Add(this.panel118);
            this.panel114.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel114.Location = new System.Drawing.Point(0, 494);
            this.panel114.Name = "panel114";
            this.panel114.Size = new System.Drawing.Size(814, 35);
            this.panel114.TabIndex = 50;
            // 
            // panel115
            // 
            this.panel115.Controls.Add(this.customTextBox6);
            this.panel115.Controls.Add(this.label30);
            this.panel115.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel115.Location = new System.Drawing.Point(120, 0);
            this.panel115.Name = "panel115";
            this.panel115.Size = new System.Drawing.Size(694, 34);
            this.panel115.TabIndex = 5;
            // 
            // customTextBox6
            // 
            this.customTextBox6.BackColor = System.Drawing.Color.White;
            this.customTextBox6.BorderColor = System.Drawing.Color.White;
            this.customTextBox6.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox6.BorderSize = 0;
            this.customTextBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox6.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox6.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox6.Location = new System.Drawing.Point(0, 0);
            this.customTextBox6.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox6.Multiline = false;
            this.customTextBox6.Name = "customTextBox6";
            this.customTextBox6.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox6.PasswordChar = false;
            this.customTextBox6.Size = new System.Drawing.Size(694, 38);
            this.customTextBox6.TabIndex = 0;
            this.customTextBox6.Tag = "1";
            this.customTextBox6.Texts = "Enter Email Address";
            this.customTextBox6.UnderlinedStyle = false;
            this.customTextBox6.Enter += new System.EventHandler(this.customTextBox6_Enter);
            this.customTextBox6.Leave += new System.EventHandler(this.customTextBox6_Leave);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Left;
            this.label30.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label30.Location = new System.Drawing.Point(0, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(0, 23);
            this.label30.TabIndex = 3;
            // 
            // panel116
            // 
            this.panel116.Controls.Add(this.label31);
            this.panel116.Controls.Add(this.panel117);
            this.panel116.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel116.Location = new System.Drawing.Point(0, 0);
            this.panel116.Name = "panel116";
            this.panel116.Size = new System.Drawing.Size(120, 34);
            this.panel116.TabIndex = 4;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Right;
            this.label31.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(9, 7);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(111, 23);
            this.label31.TabIndex = 9;
            this.label31.Text = "Email Address : ";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel117
            // 
            this.panel117.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel117.Location = new System.Drawing.Point(0, 0);
            this.panel117.Name = "panel117";
            this.panel117.Size = new System.Drawing.Size(120, 7);
            this.panel117.TabIndex = 3;
            // 
            // panel118
            // 
            this.panel118.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel118.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel118.Location = new System.Drawing.Point(0, 34);
            this.panel118.Name = "panel118";
            this.panel118.Size = new System.Drawing.Size(814, 1);
            this.panel118.TabIndex = 1;
            // 
            // panel109
            // 
            this.panel109.Controls.Add(this.panel110);
            this.panel109.Controls.Add(this.panel111);
            this.panel109.Controls.Add(this.panel113);
            this.panel109.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel109.Location = new System.Drawing.Point(0, 459);
            this.panel109.Name = "panel109";
            this.panel109.Size = new System.Drawing.Size(814, 35);
            this.panel109.TabIndex = 49;
            // 
            // panel110
            // 
            this.panel110.Controls.Add(this.customTextBox5);
            this.panel110.Controls.Add(this.label28);
            this.panel110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel110.Location = new System.Drawing.Point(120, 0);
            this.panel110.Name = "panel110";
            this.panel110.Size = new System.Drawing.Size(694, 34);
            this.panel110.TabIndex = 5;
            // 
            // customTextBox5
            // 
            this.customTextBox5.BackColor = System.Drawing.Color.White;
            this.customTextBox5.BorderColor = System.Drawing.Color.White;
            this.customTextBox5.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox5.BorderSize = 0;
            this.customTextBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox5.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox5.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox5.Location = new System.Drawing.Point(0, 0);
            this.customTextBox5.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox5.Multiline = false;
            this.customTextBox5.Name = "customTextBox5";
            this.customTextBox5.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox5.PasswordChar = false;
            this.customTextBox5.Size = new System.Drawing.Size(694, 38);
            this.customTextBox5.TabIndex = 0;
            this.customTextBox5.Tag = "1";
            this.customTextBox5.Texts = "Enter Contact Number";
            this.customTextBox5.UnderlinedStyle = false;
            this.customTextBox5.Enter += new System.EventHandler(this.customTextBox5_Enter);
            this.customTextBox5.Leave += new System.EventHandler(this.customTextBox5_Leave);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Left;
            this.label28.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label28.Location = new System.Drawing.Point(0, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(0, 23);
            this.label28.TabIndex = 3;
            // 
            // panel111
            // 
            this.panel111.Controls.Add(this.label29);
            this.panel111.Controls.Add(this.panel112);
            this.panel111.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel111.Location = new System.Drawing.Point(0, 0);
            this.panel111.Name = "panel111";
            this.panel111.Size = new System.Drawing.Size(120, 34);
            this.panel111.TabIndex = 4;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Right;
            this.label29.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(-2, 7);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(122, 23);
            this.label29.TabIndex = 9;
            this.label29.Text = "Contact Number : ";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel112
            // 
            this.panel112.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel112.Location = new System.Drawing.Point(0, 0);
            this.panel112.Name = "panel112";
            this.panel112.Size = new System.Drawing.Size(120, 7);
            this.panel112.TabIndex = 3;
            // 
            // panel113
            // 
            this.panel113.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel113.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel113.Location = new System.Drawing.Point(0, 34);
            this.panel113.Name = "panel113";
            this.panel113.Size = new System.Drawing.Size(814, 1);
            this.panel113.TabIndex = 1;
            // 
            // panel99
            // 
            this.panel99.Controls.Add(this.panel100);
            this.panel99.Controls.Add(this.panel105);
            this.panel99.Controls.Add(this.panel107);
            this.panel99.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel99.Location = new System.Drawing.Point(0, 377);
            this.panel99.Name = "panel99";
            this.panel99.Size = new System.Drawing.Size(814, 82);
            this.panel99.TabIndex = 48;
            // 
            // panel100
            // 
            this.panel100.Controls.Add(this.textBox2);
            this.panel100.Controls.Add(this.panel101);
            this.panel100.Controls.Add(this.panel102);
            this.panel100.Controls.Add(this.panel103);
            this.panel100.Controls.Add(this.panel104);
            this.panel100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel100.Location = new System.Drawing.Point(120, 0);
            this.panel100.Name = "panel100";
            this.panel100.Size = new System.Drawing.Size(694, 81);
            this.panel100.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.textBox2.ForeColor = System.Drawing.Color.DimGray;
            this.textBox2.Location = new System.Drawing.Point(7, 7);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(680, 67);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "Enter Permanent Address";
            this.textBox2.Enter += new System.EventHandler(this.textBox2_Enter);
            this.textBox2.Leave += new System.EventHandler(this.textBox2_Leave);
            // 
            // panel101
            // 
            this.panel101.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel101.Location = new System.Drawing.Point(687, 7);
            this.panel101.Name = "panel101";
            this.panel101.Size = new System.Drawing.Size(7, 67);
            this.panel101.TabIndex = 7;
            // 
            // panel102
            // 
            this.panel102.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel102.Location = new System.Drawing.Point(0, 7);
            this.panel102.Name = "panel102";
            this.panel102.Size = new System.Drawing.Size(7, 67);
            this.panel102.TabIndex = 6;
            // 
            // panel103
            // 
            this.panel103.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel103.Location = new System.Drawing.Point(0, 74);
            this.panel103.Name = "panel103";
            this.panel103.Size = new System.Drawing.Size(694, 7);
            this.panel103.TabIndex = 5;
            // 
            // panel104
            // 
            this.panel104.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel104.Location = new System.Drawing.Point(0, 0);
            this.panel104.Name = "panel104";
            this.panel104.Size = new System.Drawing.Size(694, 7);
            this.panel104.TabIndex = 4;
            // 
            // panel105
            // 
            this.panel105.Controls.Add(this.label26);
            this.panel105.Controls.Add(this.panel106);
            this.panel105.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel105.Location = new System.Drawing.Point(0, 0);
            this.panel105.Name = "panel105";
            this.panel105.Size = new System.Drawing.Size(120, 81);
            this.panel105.TabIndex = 4;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Right;
            this.label26.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(-24, 30);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(144, 23);
            this.label26.TabIndex = 9;
            this.label26.Text = "Permanent Address : ";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel106
            // 
            this.panel106.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel106.Location = new System.Drawing.Point(0, 0);
            this.panel106.Name = "panel106";
            this.panel106.Size = new System.Drawing.Size(120, 30);
            this.panel106.TabIndex = 3;
            // 
            // panel107
            // 
            this.panel107.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel107.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel107.Location = new System.Drawing.Point(0, 81);
            this.panel107.Name = "panel107";
            this.panel107.Size = new System.Drawing.Size(814, 1);
            this.panel107.TabIndex = 1;
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.panel91);
            this.panel90.Controls.Add(this.panel92);
            this.panel90.Controls.Add(this.panel94);
            this.panel90.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel90.Location = new System.Drawing.Point(0, 295);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(814, 82);
            this.panel90.TabIndex = 47;
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.textBox1);
            this.panel91.Controls.Add(this.panel98);
            this.panel91.Controls.Add(this.panel97);
            this.panel91.Controls.Add(this.panel96);
            this.panel91.Controls.Add(this.panel95);
            this.panel91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel91.Location = new System.Drawing.Point(120, 0);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(694, 81);
            this.panel91.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.textBox1.ForeColor = System.Drawing.Color.DimGray;
            this.textBox1.Location = new System.Drawing.Point(7, 7);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(680, 67);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Enter Present Address";
            this.textBox1.Enter += new System.EventHandler(this.textBox1_Enter);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // panel98
            // 
            this.panel98.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel98.Location = new System.Drawing.Point(687, 7);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(7, 67);
            this.panel98.TabIndex = 7;
            // 
            // panel97
            // 
            this.panel97.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel97.Location = new System.Drawing.Point(0, 7);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(7, 67);
            this.panel97.TabIndex = 6;
            // 
            // panel96
            // 
            this.panel96.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel96.Location = new System.Drawing.Point(0, 74);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(694, 7);
            this.panel96.TabIndex = 5;
            // 
            // panel95
            // 
            this.panel95.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel95.Location = new System.Drawing.Point(0, 0);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(694, 7);
            this.panel95.TabIndex = 4;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.label27);
            this.panel92.Controls.Add(this.panel93);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel92.Location = new System.Drawing.Point(0, 0);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(120, 81);
            this.panel92.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Right;
            this.label27.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(-4, 30);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(124, 23);
            this.label27.TabIndex = 9;
            this.label27.Text = "Present Address : ";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel93
            // 
            this.panel93.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel93.Location = new System.Drawing.Point(0, 0);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(120, 30);
            this.panel93.TabIndex = 3;
            // 
            // panel94
            // 
            this.panel94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel94.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel94.Location = new System.Drawing.Point(0, 81);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(814, 1);
            this.panel94.TabIndex = 1;
            // 
            // panel58
            // 
            this.panel58.Controls.Add(this.panel59);
            this.panel58.Controls.Add(this.panel60);
            this.panel58.Controls.Add(this.panel62);
            this.panel58.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel58.Location = new System.Drawing.Point(0, 260);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(814, 35);
            this.panel58.TabIndex = 36;
            // 
            // panel59
            // 
            this.panel59.Controls.Add(this.customTextBox9);
            this.panel59.Controls.Add(this.label16);
            this.panel59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel59.Location = new System.Drawing.Point(120, 0);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(694, 34);
            this.panel59.TabIndex = 5;
            // 
            // customTextBox9
            // 
            this.customTextBox9.BackColor = System.Drawing.Color.White;
            this.customTextBox9.BorderColor = System.Drawing.Color.White;
            this.customTextBox9.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox9.BorderSize = 0;
            this.customTextBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox9.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox9.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox9.Location = new System.Drawing.Point(0, 0);
            this.customTextBox9.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox9.Multiline = false;
            this.customTextBox9.Name = "customTextBox9";
            this.customTextBox9.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox9.PasswordChar = false;
            this.customTextBox9.Size = new System.Drawing.Size(694, 38);
            this.customTextBox9.TabIndex = 0;
            this.customTextBox9.Tag = "1";
            this.customTextBox9.Texts = "Enter Password";
            this.customTextBox9.UnderlinedStyle = false;
            this.customTextBox9.Enter += new System.EventHandler(this.customTextBox9_Enter);
            this.customTextBox9.Leave += new System.EventHandler(this.customTextBox9_Leave);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Left;
            this.label16.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 23);
            this.label16.TabIndex = 3;
            // 
            // panel60
            // 
            this.panel60.Controls.Add(this.label17);
            this.panel60.Controls.Add(this.panel61);
            this.panel60.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel60.Location = new System.Drawing.Point(0, 0);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(120, 34);
            this.panel60.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Right;
            this.label17.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(37, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 23);
            this.label17.TabIndex = 9;
            this.label17.Text = "Password : ";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel61
            // 
            this.panel61.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel61.Location = new System.Drawing.Point(0, 0);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(120, 7);
            this.panel61.TabIndex = 3;
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel62.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel62.Location = new System.Drawing.Point(0, 34);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(814, 1);
            this.panel62.TabIndex = 1;
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.panel48);
            this.panel47.Controls.Add(this.panel49);
            this.panel47.Controls.Add(this.panel51);
            this.panel47.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel47.Location = new System.Drawing.Point(0, 225);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(814, 35);
            this.panel47.TabIndex = 34;
            // 
            // panel48
            // 
            this.panel48.Controls.Add(this.comboBox8);
            this.panel48.Controls.Add(this.panel88);
            this.panel48.Controls.Add(this.label11);
            this.panel48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel48.Location = new System.Drawing.Point(120, 0);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(694, 34);
            this.panel48.TabIndex = 5;
            // 
            // comboBox8
            // 
            this.comboBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox8.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.comboBox8.ForeColor = System.Drawing.Color.DimGray;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            " MALE",
            " FEMALE"});
            this.comboBox8.Location = new System.Drawing.Point(0, 3);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(694, 30);
            this.comboBox8.TabIndex = 6;
            this.comboBox8.SelectedIndexChanged += new System.EventHandler(this.comboBox8_SelectedIndexChanged);
            this.comboBox8.Enter += new System.EventHandler(this.comboBox8_Enter);
            // 
            // panel88
            // 
            this.panel88.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel88.Location = new System.Drawing.Point(0, 0);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(694, 3);
            this.panel88.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Left;
            this.label11.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label11.Location = new System.Drawing.Point(0, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 23);
            this.label11.TabIndex = 3;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.label13);
            this.panel49.Controls.Add(this.panel50);
            this.panel49.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(120, 34);
            this.panel49.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Right;
            this.label13.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(77, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 23);
            this.label13.TabIndex = 9;
            this.label13.Text = "Sex : ";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel50
            // 
            this.panel50.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel50.Location = new System.Drawing.Point(0, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(120, 7);
            this.panel50.TabIndex = 3;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel51.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel51.Location = new System.Drawing.Point(0, 34);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(814, 1);
            this.panel51.TabIndex = 1;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Controls.Add(this.panel35);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel31.Location = new System.Drawing.Point(0, 190);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(814, 35);
            this.panel31.TabIndex = 31;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.dateTimePicker1);
            this.panel32.Controls.Add(this.panel108);
            this.panel32.Controls.Add(this.panel89);
            this.panel32.Controls.Add(this.label2);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(120, 0);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(694, 34);
            this.panel32.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dateTimePicker1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.dateTimePicker1.Location = new System.Drawing.Point(7, 7);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(687, 29);
            this.dateTimePicker1.TabIndex = 10;
            // 
            // panel108
            // 
            this.panel108.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel108.Location = new System.Drawing.Point(0, 7);
            this.panel108.Name = "panel108";
            this.panel108.Size = new System.Drawing.Size(7, 27);
            this.panel108.TabIndex = 7;
            // 
            // panel89
            // 
            this.panel89.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel89.Location = new System.Drawing.Point(0, 0);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(694, 7);
            this.panel89.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Left;
            this.label2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 23);
            this.label2.TabIndex = 3;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label3);
            this.panel33.Controls.Add(this.panel34);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(120, 34);
            this.panel33.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(70, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 23);
            this.label3.TabIndex = 9;
            this.label3.Text = "DOB :  ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel34
            // 
            this.panel34.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(120, 7);
            this.panel34.TabIndex = 3;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel35.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel35.Location = new System.Drawing.Point(0, 34);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(814, 1);
            this.panel35.TabIndex = 1;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Controls.Add(this.panel28);
            this.panel26.Controls.Add(this.panel30);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel26.Location = new System.Drawing.Point(0, 155);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(814, 35);
            this.panel26.TabIndex = 16;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.customTextBox4);
            this.panel27.Controls.Add(this.program);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(120, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(694, 34);
            this.panel27.TabIndex = 5;
            // 
            // customTextBox4
            // 
            this.customTextBox4.BackColor = System.Drawing.Color.White;
            this.customTextBox4.BorderColor = System.Drawing.Color.White;
            this.customTextBox4.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox4.BorderSize = 0;
            this.customTextBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox4.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox4.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox4.Location = new System.Drawing.Point(0, 0);
            this.customTextBox4.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox4.Multiline = false;
            this.customTextBox4.Name = "customTextBox4";
            this.customTextBox4.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox4.PasswordChar = false;
            this.customTextBox4.Size = new System.Drawing.Size(694, 38);
            this.customTextBox4.TabIndex = 0;
            this.customTextBox4.Tag = "1";
            this.customTextBox4.Texts = "Enter Father\'s Name";
            this.customTextBox4.UnderlinedStyle = false;
            this.customTextBox4.Enter += new System.EventHandler(this.customTextBox4_Enter);
            this.customTextBox4.Leave += new System.EventHandler(this.customTextBox4_Leave);
            // 
            // program
            // 
            this.program.AutoSize = true;
            this.program.Dock = System.Windows.Forms.DockStyle.Left;
            this.program.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.program.Location = new System.Drawing.Point(0, 0);
            this.program.Name = "program";
            this.program.Size = new System.Drawing.Size(0, 23);
            this.program.TabIndex = 3;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.label12);
            this.panel28.Controls.Add(this.panel29);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(120, 34);
            this.panel28.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Right;
            this.label12.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(19, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 23);
            this.label12.TabIndex = 9;
            this.label12.Text = "Father Name : ";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel29
            // 
            this.panel29.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel29.Location = new System.Drawing.Point(0, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(120, 7);
            this.panel29.TabIndex = 3;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel30.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel30.Location = new System.Drawing.Point(0, 34);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(814, 1);
            this.panel30.TabIndex = 1;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Controls.Add(this.panel23);
            this.panel21.Controls.Add(this.panel25);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(0, 120);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(814, 35);
            this.panel21.TabIndex = 15;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.customTextBox3);
            this.panel22.Controls.Add(this.credit);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(120, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(694, 34);
            this.panel22.TabIndex = 5;
            // 
            // customTextBox3
            // 
            this.customTextBox3.BackColor = System.Drawing.Color.White;
            this.customTextBox3.BorderColor = System.Drawing.Color.White;
            this.customTextBox3.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox3.BorderSize = 0;
            this.customTextBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox3.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox3.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox3.Location = new System.Drawing.Point(0, 0);
            this.customTextBox3.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox3.Multiline = false;
            this.customTextBox3.Name = "customTextBox3";
            this.customTextBox3.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox3.PasswordChar = false;
            this.customTextBox3.Size = new System.Drawing.Size(694, 38);
            this.customTextBox3.TabIndex = 0;
            this.customTextBox3.Tag = "1";
            this.customTextBox3.Texts = "Enter Mother\'s Name";
            this.customTextBox3.UnderlinedStyle = false;
            this.customTextBox3.Enter += new System.EventHandler(this.customTextBox3_Enter);
            this.customTextBox3.Leave += new System.EventHandler(this.customTextBox3_Leave);
            // 
            // credit
            // 
            this.credit.AutoSize = true;
            this.credit.Dock = System.Windows.Forms.DockStyle.Left;
            this.credit.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.credit.Location = new System.Drawing.Point(0, 0);
            this.credit.Name = "credit";
            this.credit.Size = new System.Drawing.Size(0, 23);
            this.credit.TabIndex = 3;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label10);
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel23.Location = new System.Drawing.Point(0, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(120, 34);
            this.panel23.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Right;
            this.label10.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(16, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 23);
            this.label10.TabIndex = 9;
            this.label10.Text = "Mother Name : ";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel24
            // 
            this.panel24.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(120, 7);
            this.panel24.TabIndex = 3;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel25.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel25.Location = new System.Drawing.Point(0, 34);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(814, 1);
            this.panel25.TabIndex = 1;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Controls.Add(this.panel18);
            this.panel16.Controls.Add(this.panel20);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 85);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(814, 35);
            this.panel16.TabIndex = 14;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.customTextBox2);
            this.panel17.Controls.Add(this.cgpa);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(120, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(694, 34);
            this.panel17.TabIndex = 5;
            // 
            // customTextBox2
            // 
            this.customTextBox2.BackColor = System.Drawing.Color.White;
            this.customTextBox2.BorderColor = System.Drawing.Color.White;
            this.customTextBox2.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox2.BorderSize = 0;
            this.customTextBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox2.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox2.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox2.Location = new System.Drawing.Point(0, 0);
            this.customTextBox2.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox2.Multiline = false;
            this.customTextBox2.Name = "customTextBox2";
            this.customTextBox2.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox2.PasswordChar = false;
            this.customTextBox2.Size = new System.Drawing.Size(694, 38);
            this.customTextBox2.TabIndex = 0;
            this.customTextBox2.Tag = "1";
            this.customTextBox2.Texts = "Enter Teacher Name";
            this.customTextBox2.UnderlinedStyle = false;
            this.customTextBox2.Enter += new System.EventHandler(this.customTextBox2_Enter);
            this.customTextBox2.Leave += new System.EventHandler(this.customTextBox2_Leave);
            // 
            // cgpa
            // 
            this.cgpa.AutoSize = true;
            this.cgpa.Dock = System.Windows.Forms.DockStyle.Left;
            this.cgpa.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.cgpa.Location = new System.Drawing.Point(0, 0);
            this.cgpa.Name = "cgpa";
            this.cgpa.Size = new System.Drawing.Size(0, 23);
            this.cgpa.TabIndex = 3;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label8);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(120, 34);
            this.panel18.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Right;
            this.label8.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(-3, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 23);
            this.label8.TabIndex = 5;
            this.label8.Text = " Employee Name : ";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel19
            // 
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(120, 7);
            this.panel19.TabIndex = 4;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel20.Location = new System.Drawing.Point(0, 34);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(814, 1);
            this.panel20.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel14);
            this.panel11.Controls.Add(this.panel15);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 50);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(814, 35);
            this.panel11.TabIndex = 13;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.customTextBox1);
            this.panel14.Controls.Add(this.studentId);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(120, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(694, 34);
            this.panel14.TabIndex = 5;
            // 
            // customTextBox1
            // 
            this.customTextBox1.BackColor = System.Drawing.Color.White;
            this.customTextBox1.BorderColor = System.Drawing.Color.White;
            this.customTextBox1.BorderFocusColor = System.Drawing.Color.White;
            this.customTextBox1.BorderSize = 0;
            this.customTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.customTextBox1.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.customTextBox1.ForeColor = System.Drawing.Color.DimGray;
            this.customTextBox1.Location = new System.Drawing.Point(0, 0);
            this.customTextBox1.Margin = new System.Windows.Forms.Padding(4);
            this.customTextBox1.Multiline = false;
            this.customTextBox1.Name = "customTextBox1";
            this.customTextBox1.Padding = new System.Windows.Forms.Padding(7);
            this.customTextBox1.PasswordChar = false;
            this.customTextBox1.Size = new System.Drawing.Size(694, 38);
            this.customTextBox1.TabIndex = 0;
            this.customTextBox1.Tag = "1";
            this.customTextBox1.Texts = "Enter Student Id";
            this.customTextBox1.UnderlinedStyle = false;
            this.customTextBox1.Enter += new System.EventHandler(this.customTextBox1_Enter);
            // 
            // studentId
            // 
            this.studentId.AutoSize = true;
            this.studentId.Dock = System.Windows.Forms.DockStyle.Left;
            this.studentId.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F);
            this.studentId.Location = new System.Drawing.Point(0, 0);
            this.studentId.Name = "studentId";
            this.studentId.Size = new System.Drawing.Size(0, 23);
            this.studentId.TabIndex = 3;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label6);
            this.panel15.Controls.Add(this.panel13);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(120, 34);
            this.panel15.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Right;
            this.label6.Font = new System.Drawing.Font("Bahnschrift Condensed", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(24, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 23);
            this.label6.TabIndex = 5;
            this.label6.Text = "Employee Id : ";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel13
            // 
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(120, 7);
            this.panel13.TabIndex = 4;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel12.Location = new System.Drawing.Point(0, 34);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(814, 1);
            this.panel12.TabIndex = 1;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(177)))), ((int)(((byte)(25)))));
            this.panel10.Controls.Add(this.label1);
            this.panel10.Controls.Add(this.panel131);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(814, 50);
            this.panel10.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(358, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 37);
            this.label1.TabIndex = 2;
            this.label1.Text = "Insert a Student";
            // 
            // panel131
            // 
            this.panel131.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(221)))), ((int)(((byte)(221)))));
            this.panel131.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel131.Location = new System.Drawing.Point(0, 49);
            this.panel131.Name = "panel131";
            this.panel131.Size = new System.Drawing.Size(814, 1);
            this.panel131.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button1);
            this.panel7.Controls.Add(this.loginBtn);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel7.Location = new System.Drawing.Point(0, 966);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(814, 69);
            this.panel7.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(127)))), ((int)(((byte)(175)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(188, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(221, 58);
            this.button1.TabIndex = 7;
            this.button1.Text = "CLEAR";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // loginBtn
            // 
            this.loginBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(127)))), ((int)(((byte)(175)))));
            this.loginBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginBtn.FlatAppearance.BorderSize = 0;
            this.loginBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.loginBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(9)))), ((int)(((byte)(79)))), ((int)(((byte)(159)))));
            this.loginBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginBtn.ForeColor = System.Drawing.Color.White;
            this.loginBtn.Location = new System.Drawing.Point(460, 5);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(221, 58);
            this.loginBtn.TabIndex = 0;
            this.loginBtn.Text = "INSERT";
            this.loginBtn.UseVisualStyleBackColor = false;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(824, 10);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 1035);
            this.panel4.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 10);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 1035);
            this.panel3.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 1045);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(834, 10);
            this.panel2.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(834, 10);
            this.panel5.TabIndex = 4;
            // 
            // addTeacher
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(834, 1055);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "addTeacher";
            this.Text = "addTeacher";
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel144.ResumeLayout(false);
            this.panel145.ResumeLayout(false);
            this.panel145.PerformLayout();
            this.panel148.ResumeLayout(false);
            this.panel148.PerformLayout();
            this.panel138.ResumeLayout(false);
            this.panel139.ResumeLayout(false);
            this.panel139.PerformLayout();
            this.panel141.ResumeLayout(false);
            this.panel141.PerformLayout();
            this.panel132.ResumeLayout(false);
            this.panel133.ResumeLayout(false);
            this.panel133.PerformLayout();
            this.panel135.ResumeLayout(false);
            this.panel135.PerformLayout();
            this.panel125.ResumeLayout(false);
            this.panel126.ResumeLayout(false);
            this.panel126.PerformLayout();
            this.panel128.ResumeLayout(false);
            this.panel128.PerformLayout();
            this.panel119.ResumeLayout(false);
            this.panel120.ResumeLayout(false);
            this.panel120.PerformLayout();
            this.panel122.ResumeLayout(false);
            this.panel122.PerformLayout();
            this.panel114.ResumeLayout(false);
            this.panel115.ResumeLayout(false);
            this.panel115.PerformLayout();
            this.panel116.ResumeLayout(false);
            this.panel116.PerformLayout();
            this.panel109.ResumeLayout(false);
            this.panel110.ResumeLayout(false);
            this.panel110.PerformLayout();
            this.panel111.ResumeLayout(false);
            this.panel111.PerformLayout();
            this.panel99.ResumeLayout(false);
            this.panel100.ResumeLayout(false);
            this.panel100.PerformLayout();
            this.panel105.ResumeLayout(false);
            this.panel105.PerformLayout();
            this.panel90.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.panel92.ResumeLayout(false);
            this.panel92.PerformLayout();
            this.panel58.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel59.PerformLayout();
            this.panel60.ResumeLayout(false);
            this.panel60.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel144;
        private System.Windows.Forms.Panel panel145;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Panel panel146;
        private System.Windows.Forms.Panel panel147;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel148;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel149;
        private System.Windows.Forms.Panel panel150;
        private System.Windows.Forms.Panel panel138;
        private System.Windows.Forms.Panel panel139;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Panel panel140;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel141;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel142;
        private System.Windows.Forms.Panel panel143;
        private System.Windows.Forms.Panel panel132;
        private System.Windows.Forms.Panel panel133;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Panel panel134;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel135;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel136;
        private System.Windows.Forms.Panel panel137;
        private System.Windows.Forms.Panel panel125;
        private System.Windows.Forms.Panel panel126;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Panel panel127;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel128;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel129;
        private System.Windows.Forms.Panel panel130;
        private System.Windows.Forms.Panel panel119;
        private System.Windows.Forms.Panel panel120;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Panel panel121;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel122;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel123;
        private System.Windows.Forms.Panel panel124;
        private System.Windows.Forms.Panel panel114;
        private System.Windows.Forms.Panel panel115;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox6;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel116;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel117;
        private System.Windows.Forms.Panel panel118;
        private System.Windows.Forms.Panel panel109;
        private System.Windows.Forms.Panel panel110;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel111;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel112;
        private System.Windows.Forms.Panel panel113;
        private System.Windows.Forms.Panel panel99;
        private System.Windows.Forms.Panel panel100;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel101;
        private System.Windows.Forms.Panel panel102;
        private System.Windows.Forms.Panel panel103;
        private System.Windows.Forms.Panel panel104;
        private System.Windows.Forms.Panel panel105;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel106;
        private System.Windows.Forms.Panel panel107;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel98;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel96;
        private System.Windows.Forms.Panel panel95;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.Panel panel94;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel59;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel108;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox4;
        private System.Windows.Forms.Label program;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox3;
        private System.Windows.Forms.Label credit;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox2;
        private System.Windows.Forms.Label cgpa;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel14;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox1;
        private System.Windows.Forms.Label studentId;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel131;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel37;
        private WindowsFormsApp2.Custom.CustomTextBox customTextBox7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
    }
}