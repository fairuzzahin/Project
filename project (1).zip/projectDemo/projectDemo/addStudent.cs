﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2.Custom;
using System.Configuration;
using System.Text.RegularExpressions;

namespace projectDemo
{
    public partial class addStudent : Form
    {
        string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|" + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)" + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

        public addStudent()
        {
            InitializeComponent();
            loadComboBox();
            usersIdIncrement();
        }

        //function for comboBox to load at first
        public void loadComboBox()
        {
            comboBox("SELECT * FROM Department", "dId", "dName", comboBox3);
            comboBox("SELECT * FROM Gender", "gId", "gName", comboBox8);
            comboBox("SELECT * FROM Nationality", "nId", "nName", comboBox9);
            comboBox("SELECT * FROM Religion", "rId", "rName", comboBox10);
            comboBox("SELECT * FROM MaritalStatus", "mId", "mName", comboBox11);
            comboBox("SELECT * FROM BloodGroup", "bId", "bName", comboBox12);
        }

        //function to auto increment id 
        public void usersIdIncrement()
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

            SqlDataAdapter sqladptr = new SqlDataAdapter("SELECT Id FROM Users", sqlCon);

            DataTable dt = new DataTable();
            sqladptr.Fill(dt);

            if(dt.Rows.Count < 1)
            {
                customTextBox1.Texts = "1";
                customTextBox1.ForeColor = Color.Black;
            }
            else
            {
                SqlCommand sqladptr1 = new SqlCommand("SELECT MAX(Id) FROM Users", sqlCon);
                sqlCon.Open();
                int a = Convert.ToInt32(sqladptr1.ExecuteScalar());
                sqlCon.Close();
                a = a + 1;
                customTextBox1.Texts = a.ToString();
                customTextBox1.ForeColor = Color.Black;
            }

        }

        //function for a comboBox to select data from database table
        public void comboBox(string q, string tc1, string tc2, ComboBox combobox)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

            SqlCommand sqlcom = new SqlCommand(q, sqlCon);

            sqlCon.Open();

            SqlDataAdapter sqldpt = new SqlDataAdapter(sqlcom);

            DataTable dt = new DataTable();
            sqldpt.Fill(dt);

            combobox.ValueMember = tc1;
            combobox.DisplayMember = tc2;
            combobox.DataSource = dt;

            sqlCon.Close();
        }

        //function for a dependent comboBox to select data from database table
        public void dComboBox(string q, string tc1, string tc2, string dtc1, ComboBox combobox, ComboBox dcombobox)
        {
            if (dcombobox.SelectedValue.ToString() != null)
            {
                SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                SqlCommand sqlcom = new SqlCommand(q, sqlCon);
                sqlCon.Open();
                sqlcom.Parameters.AddWithValue(dtc1, dcombobox.SelectedValue.ToString());
                SqlDataAdapter sqldpt = new SqlDataAdapter(sqlcom);

                DataTable dt = new DataTable();
                sqldpt.Fill(dt);

                combobox.ValueMember = tc1;
                combobox.DisplayMember = tc2;
                combobox.DataSource = dt;

                sqlCon.Close();
            }
        }

        //function to reset textBox and comboBox after insert a student 
        public void resertInsert()
        {
            customTextBox9.Texts = "";
            customTextBox2.Texts = "";
            customTextBox3.Texts = "";
            customTextBox4.Texts = "";
            loadComboBox();
            textBox1.Text = "";
            textBox2.Text = "";
            customTextBox5.Texts = "";
            customTextBox6.Texts = "";

            leaveReset(customTextBox2, "Enter Student Name");
            leaveReset(customTextBox3, "Enter Mother's Name");
            leaveReset(customTextBox4, "Enter Father's Name");
            leaveReset(customTextBox5, "Enter Contact Number");
            leaveReset(customTextBox6, "Enter Email Address");
            leaveReset(textBox1, "Enter Present Address");
            leaveReset(textBox2, "Enter Permanent Address");
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        //function for a customTextBox when it is blank
        public void blankWarnimg(CustomTextBox textbox)
        {
            if (textbox.ForeColor == Color.DimGray)
            {
                textbox.ForeColor = Color.Red;
            }
        }

        //function for a textBox when it is blank
        public void blankWarnimg(TextBox textbox)
        {
            if (textbox.ForeColor == Color.DimGray)
            {
                textbox.ForeColor = Color.Red;
            }
        }

        //function for a comboBox when it is blank
        public void blankWarnimg(ComboBox combobox)
        {
            if (combobox.ForeColor == Color.DimGray)
            {
                combobox.ForeColor = Color.Red;
            }
        }

        //function for click enter on a customTextBox
        public void enterReset(CustomTextBox textbox, String s)  
        {
            if (textbox.Texts == s)
            {
                textbox.Texts = "";
                textbox.ForeColor = Color.Black;
            }
        }

        //function for click leave from a customTextBox
        public void leaveReset(TextBox textbox, String s)  
        {
            if (textbox.Text == "")
            {
                textbox.Text = s;
                textbox.ForeColor = Color.DimGray;
            }
        }

        //function for click enter on a textBox
        public void enterReset(TextBox textbox, String s) 
        {
            if (textbox.Text == s)
            {
                textbox.Text = "";
                textbox.ForeColor = Color.Black;
            }
        }

        //function for click leave from a textBox
        public void leaveReset(CustomTextBox textbox, String s) 
        {
            if (textbox.Texts == "")
            {
                textbox.Texts = s;
                textbox.ForeColor = Color.DimGray;
            }
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if(customTextBox1.ForeColor == Color.Black 
                && customTextBox2.ForeColor == Color.Black 
                && customTextBox3.ForeColor == Color.Black
                && customTextBox4.ForeColor == Color.Black
                && customTextBox5.ForeColor == Color.Black
                && customTextBox6.ForeColor == Color.Black
                && customTextBox9.ForeColor == Color.Black
                && textBox1.ForeColor == Color.Black
                && textBox2.ForeColor == Color.Black
                && comboBox1.ForeColor == Color.Black
                && comboBox3.ForeColor == Color.Black
                && comboBox8.ForeColor == Color.Black
                && comboBox9.ForeColor == Color.Black
                && comboBox10.ForeColor == Color.Black
                && comboBox11.ForeColor == Color.Black
                && comboBox12.ForeColor == Color.Black)
            {
                try
                {
                    SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\projectDemo\projectDemo\loginDatabase.mdf;Integrated Security=True");

                    sqlCon.Open();

                    String queryUsersAdd = "INSERT INTO Users VALUES(@Id, @password, @name, @fatherName, @motherName, " +
                        "@dob, @gender, @department, @program, @core, @major, @SecondMajor, @minor, @elective," +
                        " @presentAddress, @permanentAddress, @contactNumber, @emailAddress, @nationality, " +
                        "@religion, @bloodGroup, @maritalStatus, @admissionDate, @semester, @cgpa, @credit)";

                    SqlCommand sqlcmdAdd = new SqlCommand(queryUsersAdd, sqlCon);

                    sqlcmdAdd.CommandType = CommandType.Text;

                    sqlcmdAdd.Parameters.AddWithValue("@Id", customTextBox1.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@password", customTextBox9.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@name", customTextBox2.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@fatherName", customTextBox3.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@motherName", customTextBox4.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@dob", dateTimePicker1.Value.ToString().Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@gender", comboBox8.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@program", comboBox1.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@department", comboBox3.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@core", comboBox2.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@major", comboBox4.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@SecondMajor", comboBox5.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@minor", comboBox6.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@elective", comboBox7.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@presentAddress", textBox1.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@permanentAddress", textBox2.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@contactNumber", customTextBox5.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@emailAddress", customTextBox6.Texts.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@nationality", comboBox9.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@religion", comboBox10.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@bloodGroup", comboBox12.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@maritalStatus", comboBox11.Text.Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@admissionDate", dateTimePicker2.Value.ToString().Trim());
                    sqlcmdAdd.Parameters.AddWithValue("@semester", "");
                    sqlcmdAdd.Parameters.AddWithValue("@cgpa", "");
                    sqlcmdAdd.Parameters.AddWithValue("@credit", "");

                    int a = sqlcmdAdd.ExecuteNonQuery();

                    sqlCon.Close();

                    if (a>0)
                    {
                        MessageBox.Show("Successful");
                        usersIdIncrement();
                        resertInsert();
                    }
                    else
                    {
                        MessageBox.Show("Not Successful");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Something Wrong");
                }
            }
            else
            {
                blankWarnimg(customTextBox1);
                blankWarnimg(customTextBox2);
                blankWarnimg(customTextBox9);
                blankWarnimg(customTextBox3);
                blankWarnimg(customTextBox4);
                blankWarnimg(customTextBox5);
                blankWarnimg(customTextBox6);
                blankWarnimg(textBox1);
                blankWarnimg(textBox2);
                blankWarnimg(comboBox3);
                blankWarnimg(comboBox1);
                blankWarnimg(comboBox8);
                blankWarnimg(comboBox9);
                blankWarnimg(comboBox10);
                blankWarnimg(comboBox11);
                blankWarnimg(comboBox12);

                MessageBox.Show("Red Field Must Fill Up");
            }
        }
        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox1, "Enter Student Id");
            MessageBox.Show("You can not change this field");
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox1, "Enter Student Id");
        }

        private void customTextBox2_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox2, "Enter Student Name");
        }

        private void customTextBox2_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox2, "Enter Student Name");
        }

        private void customTextBox9_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox9, "Enter Password");
        }

        private void customTextBox9_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox9, "Enter Password");
        }

        private void customTextBox3_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox3, "Enter Mother's Name");
        }

        private void customTextBox3_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox3, "Enter Mother's Name");
        }

        private void customTextBox4_Enter(object sender, EventArgs e)
        {
            enterReset(customTextBox4, "Enter Father's Name");
        }

        private void customTextBox4_Leave(object sender, EventArgs e)
        {
            leaveReset(customTextBox4, "Enter Father's Name");
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == " AT FIRST SELECT DEPARTMENT")
            {
                comboBox1.ForeColor = Color.DimGray;
            }
            else
                comboBox1.ForeColor = Color.Black;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            dComboBox("SELECT * FROM Program WHERE dId=@dId", "pId", "pName", "dId", comboBox1, comboBox3);
            if (comboBox3.Text == " SELECT ONE")
            {
                comboBox3.ForeColor = Color.DimGray;
            }
            else
                comboBox3.ForeColor = Color.Black;
        }

        public void aftrBlnkWrng(ComboBox combobox)
        {
            if (combobox.ForeColor == Color.Red)
            {
                combobox.ForeColor = Color.DimGray;
            }
        }

        private void comboBox3_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox3);

        }

        private void comboBox1_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox1);
        }

        private void customTextBox5_Enter_1(object sender, EventArgs e)
        {
            enterReset(customTextBox5, "Enter Contact Number");
        }
        private void customTextBox5_Leave_1(object sender, EventArgs e)
        {
            leaveReset(customTextBox5, "Enter Contact Number");
            if (customTextBox5.Texts != "Enter Contact Number")
            {
                if (new Regex(@"^(?:\+?88|0088)?01[15-9]\d{8}$").IsMatch(customTextBox5.Texts))
                {
                    //MessageBox.Show("Mobile number is valide", "All information is required", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    customTextBox5.Focus();
                    MessageBox.Show("Mobile number is not valide", "All information is required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
        }

        private void customTextBox6_Enter_1(object sender, EventArgs e)
        {
            enterReset(customTextBox6, "Enter Email Address");
        }

        private void customTextBox6_Leave_1(object sender, EventArgs e)
        {
            leaveReset(customTextBox6, "Enter Email Address");

            if (customTextBox6.Texts != "Enter Email Address")
            {
                if(Regex.IsMatch(customTextBox6.Texts,pattern) == false)
                {
                    customTextBox6.Focus();
                    MessageBox.Show("Email Address is not valide", "All information is required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            enterReset(textBox1, "Enter Present Address");
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            leaveReset(textBox1, "Enter Present Address");
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            enterReset(textBox2, "Enter Permanent Address");
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            leaveReset(textBox2, "Enter Permanent Address");
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox8.Text == " SELECT GENDER")
            {
                comboBox8.ForeColor = Color.DimGray;
            }
            else
                comboBox8.ForeColor = Color.Black;
        }

        private void comboBox8_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox8);
        }

        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox9.Text == " SELECT NATIONALITY")
            {
                comboBox9.ForeColor = Color.DimGray;
            }
            else
                comboBox9.ForeColor = Color.Black;
        }

        private void comboBox9_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox9);
        }

        private void customTextBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You can not change this field");
        }

        private void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox10.Text == " SELECT RELIGION")
            {
                comboBox10.ForeColor = Color.DimGray;
            }
            else
                comboBox10.ForeColor = Color.Black;
        }

        private void comboBox11_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox11.Text == " SELECT MARITAL STATUS")
            {
                comboBox11.ForeColor = Color.DimGray;
            }
            else
                comboBox11.ForeColor = Color.Black;
        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox12.Text == " SELECT BLOOD GROUP")
            {
                comboBox12.ForeColor = Color.DimGray;
            }
            else
                comboBox12.ForeColor = Color.Black;
        }

        private void comboBox10_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox10);
        }

        private void comboBox11_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox11);
        }

        private void comboBox12_Enter(object sender, EventArgs e)
        {
            aftrBlnkWrng(comboBox12);
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void customTextBox1__TextChanged(object sender, EventArgs e)
        {

        }
    }
}
